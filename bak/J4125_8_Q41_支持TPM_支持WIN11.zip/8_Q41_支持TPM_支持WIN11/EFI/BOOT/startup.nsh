@for %a run (0 99 1)
@  if exist fs%a:\auto.nsh then
@    fs%a:
@    goto AUTO
@  endif
@endfor

@goto END

:AUTO
@\auto.nsh

@if %lasterror% == 0 then
@  goto END
@endif

:END
