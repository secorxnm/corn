cd BIOS
fb.nsh
