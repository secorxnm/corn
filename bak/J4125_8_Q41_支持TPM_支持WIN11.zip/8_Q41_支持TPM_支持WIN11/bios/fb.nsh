fpt.efi -f bios.bin
