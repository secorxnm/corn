
参考教程：https://magiskcn.com/payload-dumper-go-boot.html

GitHub：https://github.com/ssut/payload-dumper-go/releases/tag/1.3.0