#!/system/bin/sh

ui_print "垃圾小米！"