sleep 25
setprop persist.vendor.cnss_diag.enable false
setprop persist.vendor.tcpdump.enable false