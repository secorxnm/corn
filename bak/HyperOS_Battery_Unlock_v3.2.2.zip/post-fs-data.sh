#!/system/bin/sh

# 节点根: 真机为空(即 /sys/...), 测试环境可重定向以便验证
SYS_ROOT="${SYS_ROOT:-}"

MODDIR=${0%/*}
[ -z "$MODDIR" ] && MODDIR="/data/adb/modules/hyperos_battery_unlock"

[ -d "$MODDIR" ] || exit 0

# 说明: 早期这段不再要求 unlocked.flag 存在。
# 原因: 只开伪装或云控(未开"解除限制")的用户, 之前会直接 exit,
# 导致开机早期系统读到的仍是真实循环数 —— 而云控/BAA 服务往往
# 在 boot_completed 之前就已读取, service.sh 补写已经晚了。
# 现在只要有开关就处理, 没有开关才退出。

has_any=0
for f in unlocked.flag fake_enabled.flag cap_enabled.flag volt_enabled.flag \
         cloud_disabled.flag cloud_mode pd_enabled.flag powersave.flag baa_fixed.flag; do
    [ -f "$MODDIR/$f" ] && has_any=1
done
[ "$has_any" = "1" ] || exit 0

# 允许充电到 100%
resetprop -n persist.sys.charging_stop_level 100 2>/dev/null || true

# 清除老化 / 云控学习数据, 防止系统重新施加限制
for d in /data/vendor/batteryantiaging /data/system/battery_config /data/misc/batteryantiaging \
         /data/system/cloud_battery_config /data/system/battery_cloud_config /data/misc/battery_cloud; do
    [ -d "$d" ] && rm -rf "$d"/* >/dev/null 2>&1 || true
done

# 早期就写入伪装值: 云控与 BAA 服务可能在 boot_completed 之前读取循环数,
# 等 service.sh 起来再写已经晚了(读到的是真实值)。
#
# 这里内联写节点而不是调 action.sh: 后者会 print_panel 并改写 module.prop,
# 在开机早期跑纯属额外开销, 且该阶段输出无处可去。
if [ -f "$MODDIR/fake_enabled.flag" ]; then
    v=$(cat "$MODDIR/fake_value" 2>/dev/null | tr -cd '0-9')
    [ -n "$v" ] || v=20
    for n in ${SYS_ROOT}/sys/class/qcom-battery/fake_cycle \
             ${SYS_ROOT}/sys/class/qcom-battery/fake_cycles \
             ${SYS_ROOT}/sys/class/xm_power/fg_master/cyclecount \
             ${SYS_ROOT}/sys/class/xm_power/fg_basic/cycle_count \
             ${SYS_ROOT}/sys/class/power_supply/battery/cycle_count \
             ${SYS_ROOT}/sys/class/power_supply/bms/cycle_count; do
        [ -f "$n" ] && chmod 644 "$n" 2>/dev/null && echo "$v" > "$n" 2>/dev/null
    done
fi

# 早期恢复容量/电压/PD 节点: 这些重启后会被内核重置。
# 同样内联, 只写节点不做别的事。
if [ -f "$MODDIR/cap_enabled.flag" ]; then
    v=$(cat "$MODDIR/cap_value" 2>/dev/null | tr -cd '0-9')
    if [ -n "$v" ]; then
        for n in ${SYS_ROOT}/sys/class/power_supply/battery/charge_full \
                 ${SYS_ROOT}/sys/class/power_supply/bms/charge_full; do
            [ -f "$n" ] && chmod 644 "$n" 2>/dev/null && echo "$v" > "$n" 2>/dev/null
        done
    fi
fi
if [ -f "$MODDIR/volt_enabled.flag" ]; then
    v=$(cat "$MODDIR/volt_target" 2>/dev/null | tr -cd '0-9')
    if [ -n "$v" ]; then
        for n in ${SYS_ROOT}/sys/class/power_supply/battery/voltage_max \
                 ${SYS_ROOT}/sys/class/power_supply/battery/constant_charge_voltage_max \
                 ${SYS_ROOT}/sys/class/power_supply/main/constant_charge_voltage_max \
                 ${SYS_ROOT}/sys/class/power_supply/bms/voltage_max; do
            [ -f "$n" ] && chmod 644 "$n" 2>/dev/null && echo "$v" > "$n" 2>/dev/null
        done
    fi
fi
if [ -f "$MODDIR/pd_enabled.flag" ]; then
    for n in ${SYS_ROOT}/sys/class/qcom-battery/pd_verifed \
             ${SYS_ROOT}/sys/class/qcom-battery/pd_verified \
             ${SYS_ROOT}/sys/class/Charging_Adapter/pd_adapter/usbpd_verifed \
             ${SYS_ROOT}/sys/class/Charging_Adapter/pd_adapter/usbpd_verified \
             ${SYS_ROOT}/sys/class/power_supply/battery/pd_verifed; do
        [ -f "$n" ] && echo 1 > "$n" 2>/dev/null
    done
fi

exit 0
