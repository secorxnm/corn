#!/system/bin/sh

MODDIR=${0%/*}
[ -z "$MODDIR" ] && MODDIR="/data/adb/modules/hyperos_battery_unlock"

# sysfs 根目录: 默认 /sys, 测试时可设为 mock 目录
SYS_ROOT="${SYS_ROOT:-}"

DISABLED_LIST="$MODDIR/disabled_pkgs.txt"

# ===== 彻底恢复一个包 =====
#
# 只做 pm enable 是不够的:
#   模块禁用时会设 appops 后台限制并可能 suspend, 若卸载时只 pm enable,
#   包虽然"启用"了但仍无法后台运行, 功能照样不正常 —— 这正是"删了模块
#   游戏工具箱还是没了、充电音效还是没了"的原因。
# 因此恢复时必须: 重置 appops -> 解除挂起 -> 对所有用户 enable
restore_pkg() {
    local t="$1" p u
    p=$(echo "$t" | sed 's|/.*||')

    cmd appops reset "$p" >/dev/null 2>&1 || true
    for op in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND BOOT_COMPLETED WAKE_LOCK; do
        cmd appops set "$p" "$op" allow >/dev/null 2>&1 || true
    done

    pm unsuspend "$p" >/dev/null 2>&1 || true
    # 待机分组限制: 被降级的包即使启用也无法正常后台运行
    cmd am set-standby-bucket "$p" active >/dev/null 2>&1 || true

    settings put global maintenance_mode_user_id 110 >/dev/null 2>&1 || true
    for u in $(pm list users 2>/dev/null | grep -oE '\{[0-9]+' | tr -d '{'); do
        pm enable --user "$u" "$p" >/dev/null 2>&1 || true
        pm enable --user "$u" "$t" >/dev/null 2>&1 || true
    done
    settings delete global maintenance_mode_user_id >/dev/null 2>&1 || true

    pm enable "$t" >/dev/null 2>&1 || true
    pm enable "$p" >/dev/null 2>&1 || true

    # 常规手段仍失败时走兜底(与 action.sh 保持一致)
    if pm list packages -d 2>/dev/null | grep -qx "package:$p"; then
        # 曾被 uninstall -k --user 0 移除的系统应用
        for u in $(pm list users 2>/dev/null | grep -oE '\{[0-9]+' | tr -d '{'); do
            pm install-existing --user "$u" "$p" >/dev/null 2>&1 || true
        done
        # 直接改状态记录文件(仅文本 XML, abx 格式跳过以免写坏)
        for f in /data/system/users/*/package-restrictions.xml \
                 "${SYS_ROOT}"/data/system/users/*/package-restrictions.xml; do
            [ -f "$f" ] || continue
            [ "$(head -c 5 "$f" 2>/dev/null)" = "<?xml" ] || continue
            grep -q "name=\"$p\"" "$f" 2>/dev/null || continue
            cp "$f" "$f.bak" 2>/dev/null || continue
            awk -v pkg="$p" '{
                if (match($0, "name=\"" pkg "\"")) {
                    gsub(/enabled="[234]"/, "enabled=\"1\"")
                    gsub(/enabled-caller="[^"]*"/, "enabled-caller=\"\"")
                }
                print
            }' "$f" > "$f.tmp" 2>/dev/null && mv "$f.tmp" "$f" 2>/dev/null || true
            chmod 660 "$f" 2>/dev/null || true
        done
    fi
    return 0
}

# 1. 终止守护进程 (用 pid 文件精确定位, 不用 pkill -f, 避免误杀无关进程)
if [ -f "$MODDIR/.service.pid" ]; then
    p=$(cat "$MODDIR/.service.pid" 2>/dev/null)
    if [ -n "$p" ] && [ -d "/proc/$p" ]; then
        kill -9 "$p" 2>/dev/null
        sleep 1
    fi
    rm -f "$MODDIR/.service.pid" 2>/dev/null
fi

# 2. 还原真实循环次数 (若之前伪装过并备份了真值)

# 从模块备份目录还原节点原值(备份名 = 路径把 / 换成 _)
restore_node_for() {
    local node="$1" name orig
    name=$(echo "${node#$SYS_ROOT}" | sed 's|/|_|g')
    orig=$(cat "$MODDIR/backup/$name" 2>/dev/null | tr -cd '0-9')
    [ -z "$orig" ] && return 1
    chmod 644 "$node" 2>/dev/null || true
    echo "$orig" > "$node" 2>/dev/null || true
    return 0
}

if [ -f "$MODDIR/real_cycle" ]; then
    real=$(cat "$MODDIR/real_cycle" 2>/dev/null | tr -cd '0-9')
    if [ -n "$real" ]; then
        for n in /sys/class/qcom-battery/fake_cycle \
                 /sys/class/qcom-battery/fake_cycles \
                 /sys/class/xm_power/fg_master/cyclecount \
                 /sys/class/xm_power/fg_basic/cycle_count \
                 /sys/class/xm_power/cyclecount \
                 /sys/class/power_supply/battery/cycle_count \
                 /sys/class/power_supply/battery/fg_cycle_count \
                 /sys/class/power_supply/battery/batt_cycle_count \
                 /sys/class/power_supply/bms/cycle_count; do
            [ -f "${SYS_ROOT}$n" ] || continue
            chmod 644 "${SYS_ROOT}$n" 2>/dev/null || true
            echo "$real" > "${SYS_ROOT}$n" 2>/dev/null || true
        done
    fi
    rm -f "$MODDIR/real_cycle" 2>/dev/null
fi

# 3. 还原 v1.3 容量 / 截止电压节点 (用备份目录里的原值)
BACKUP_DIR="$MODDIR/backup"
if [ -d "$BACKUP_DIR" ]; then
    for n in /sys/class/power_supply/battery/charge_full \
             /sys/class/power_supply/bms/charge_full \
             /sys/class/power_supply/battery/constant_charge_voltage_max \
             /sys/class/power_supply/battery/voltage_max \
             /sys/class/power_supply/main/constant_charge_voltage_max \
             /sys/class/power_supply/bms/voltage_max; do
        [ -f "${SYS_ROOT}$n" ] || continue
        # 备份名必须用逻辑路径生成(与 action.sh 的 backup_name 一致),
        # 不能带 SYS_ROOT 前缀, 否则测试/真机下都匹配不上。
        bname=$(echo "$n" | sed 's|/|_|g')
        orig=$(cat "$BACKUP_DIR/$bname" 2>/dev/null | tr -cd '0-9')
        if [ -n "$orig" ]; then
            chmod 644 "${SYS_ROOT}$n" 2>/dev/null || true
            echo "$orig" > "${SYS_ROOT}$n" 2>/dev/null || true
        fi
    done
    # 注意: 这里不能删 backup 目录
    #
    # 电压还原在更后面(第 4.5 步)还要读它。之前在这里删掉,
    # 导致电压原值读不到 —— 卸载后关机电压没被还原。
    # 统一放到脚本末尾清理。
fi

# 4. 恢复组件: 先按实际禁用清单(不遗漏), 再按已知清单兜底
#
# 之前只恢复硬编码的一小部分, 与实际禁用的包对不上, 是"删了模块功能还在"
# 的直接原因。现在以运行期记录的清单为准。
if [ -f "$DISABLED_LIST" ]; then
    while read -r pkg; do
        [ -n "$pkg" ] && restore_pkg "$pkg"
    done < "$DISABLED_LIST"
    rm -f "$DISABLED_LIST" 2>/dev/null
fi

for c in \
    com.miui.securitycenter/com.miui.powercenter.provider.PowerSaveService \
    com.miui.securitycenter/.powercenter.provider.PowerSaveService \
    com.miui.powercenter/.provider.PowerSaveService \
    com.miui.powercenter/com.miui.powercenter.provider.PowerSaveService \
    com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver \
    com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService \
    com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity \
    com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService \
    com.miui.powerkeeper \
    com.miui.daemon \
    com.xiaomi.joyose \
    com.miui.analytics \
    com.xiaomi.powerchecker \
    com.xiaomi.miservice; do
    restore_pkg "$c"
done

# 4.5 还原澎湃特性改动(BAA 配置 / PD 认证 / 省电)
if [ -d "$MODDIR/baa_backup" ]; then
    # 用映射文件取原路径: 不能靠文件名反推(文件名里的下划线会被误替换)
    if [ -f "$MODDIR/baa_backup/.map" ]; then
        while IFS='|' read -r bname f; do
            [ -n "$bname" ] && [ -n "$f" ] || continue
            [ -f "$MODDIR/baa_backup/$bname" ] || continue
            [ -f "$f" ] || continue
            for m in /odm /vendor /system; do
                case "$f" in "$m"/*) mount -o rw,remount "$m" 2>/dev/null || true ;; esac
            done
            cp "$MODDIR/baa_backup/$bname" "$f" 2>/dev/null || true
        done < "$MODDIR/baa_backup/.map"
    fi
fi
# 关机电压 / 开机电压复位(高风险项, 必须还原)
# 逐节点从备份目录还原
#
# 不能用"一个统一值"去写所有节点: 各层原值本来就不一样
# (voltage_min 可能是 3400 而 vcutoff 是 3300), 统一下去会把
# 差异抹掉, 表现为"还原了但值不对"。
# backup 目录里存的是每个节点各自的原值。
restore_thresh() {
    local n
    for n in $1; do
        [ -f "${SYS_ROOT}$n" ] || continue
        restore_node_for "${SYS_ROOT}$n"
    done
    return 0
}
SDV_NODES="/sys/class/power_supply/battery/voltage_min
/sys/class/power_supply/bms/voltage_min
/sys/class/power_supply/battery/shutdown_voltage
/sys/class/power_supply/battery/vbat_shutdown
/sys/class/qcom-battery/shutdown_voltage
/sys/class/xm_power/fg_basic/shutdown_voltage"
BOV_NODES="/sys/class/power_supply/battery/voltage_boot
/sys/class/power_supply/bms/voltage_boot
/sys/class/power_supply/battery/boot_voltage
/sys/class/power_supply/battery/poweron_voltage
/sys/class/qcom-battery/boot_voltage
/sys/class/xm_power/fg_basic/boot_voltage"
# 注意: restore_thresh 只接受节点列表一个参数。
# 之前传了(值文件, 节点列表)两个, 函数内 $1 拿到的是文件路径,
# 循环的是文件而不是节点 —— 还原等于没执行。
restore_thresh "$SDV_NODES"
restore_thresh "$BOV_NODES"
rm -f "$MODDIR/sdv_enabled.flag" "$MODDIR/sdv_value" "$MODDIR/sdv_value.orig" \
      "$MODDIR/bov_enabled.flag" "$MODDIR/bov_value" "$MODDIR/bov_value.orig" 2>/dev/null || true

# PD 认证复位
for n in /sys/class/qcom-battery/pd_verifed \
         /sys/class/qcom-battery/pd_verified \
         /sys/class/Charging_Adapter/pd_adapter/usbpd_verifed \
         /sys/class/Charging_Adapter/pd_adapter/usbpd_verified; do
    [ -f "${SYS_ROOT}$n" ] && echo 0 > "${SYS_ROOT}$n" 2>/dev/null || true
done
# 省电: 恢复广告服务与 WiFi 扫描
for p in com.miui.systemAdSolution com.miui.msa.global; do
    pm enable "$p" >/dev/null 2>&1 || true
    pm unsuspend "$p" >/dev/null 2>&1 || true
done
settings put global wifi_scan_always_enabled 1 >/dev/null 2>&1 || true
rm -rf "$MODDIR/baa_backup" "$MODDIR/baa_fixed.flag" \
       "$MODDIR/pd_enabled.flag" "$MODDIR/powersave.flag" 2>/dev/null || true

# 5. 还原云控联网属性(模块为断云控设过它, 不清会让云控一直连不上)
resetprop -n persist.sys.sc_allow_conn 1 2>/dev/null || true
resetprop --delete persist.sys.sc_allow_conn 2>/dev/null || true
# 维护模式必须清除: 若卸载时残留, 系统会一直停在维护模式,
# 表现为"应用设置里很多选项打不开"
settings delete global maintenance_mode_user_id >/dev/null 2>&1 || true

# 6. 恢复充电上限相关属性(多个命名都还原, 避免残留)
for prop in persist.sys.charging_stop_level \
            persist.sys.battery.charging_stop \
            persist.vendor.battery.charging_stop_level \
            persist.sys.bms.charging_stop_level; do
    resetprop -n "$prop" 80 2>/dev/null || true
done
settings delete global charging_stop_level >/dev/null 2>&1 || true

# 5.5 提示音相关提示
#
# 旧版本(<=3.2.1)的云控硬控会对 joyose 执行 pm clear, 清空它的私有数据,
# 连带清掉用户设置的充电提示音、游戏工具箱配置等。数据删除不可逆,
# 组件恢复之后这些设置不会自己回来。
#
# 新版本已不再自动清 joyose 数据, 但已经被清过的用户仍需手动重开,
# 所以这里明确提示路径, 免得用户以为模块没卸干净。
ui_print "------------------------------------------" 2>/dev/null || true
ui_print "若充电提示音/游戏工具箱仍然失效:" 2>/dev/null || true
ui_print "  这是旧版本清空 joyose 数据导致的, 数据删除不可恢复。" 2>/dev/null || true
ui_print "  请手动重新开启: 设置 -> 声音与振动 -> 充电提示音" 2>/dev/null || true
ui_print "  (不同机型路径可能略有差异, 可在设置里搜索「充电提示音」)" 2>/dev/null || true
ui_print "------------------------------------------" 2>/dev/null || true

# 6. 清理模块运行时文件 (模块目录随后由管理器删除)
# 备份目录放到最后删: 前面各步还原都要读它
rm -rf "$MODDIR/backup" 2>/dev/null || true
rm -f "$MODDIR/fake_value" 2>/dev/null || true
rm -f "$MODDIR/fake_enabled.flag" 2>/dev/null || true
rm -f "$MODDIR/unlocked.flag" 2>/dev/null || true
rm -f "$MODDIR/cloud_disabled.flag" 2>/dev/null || true
rm -f "$MODDIR/cap_enabled.flag" 2>/dev/null || true
rm -f "$MODDIR/cap_value" 2>/dev/null || true
rm -f "$MODDIR/volt_enabled.flag" 2>/dev/null || true
rm -f "$MODDIR/volt_target" 2>/dev/null || true
rm -rf "$MODDIR/backup" 2>/dev/null || true
rm -f "$MODDIR/.service.pid" 2>/dev/null || true
rm -f "$MODDIR/.key_tmp" 2>/dev/null || true
rm -f "$DISABLED_LIST" 2>/dev/null || true
# 充电记录与会话状态一并清理, 避免重装后残留旧数据
rm -f "$MODDIR/charge_log.jsonl" "$MODDIR/charge_sessions.jsonl" 2>/dev/null || true
rm -f "$MODDIR/charge_log_enabled.flag" 2>/dev/null || true
rm -f "$MODDIR/.charging" "$MODDIR/.charging.from" "$MODDIR/.charging.last" \
      "$MODDIR/.charging.lastt" "$MODDIR/.charging.n" \
      "$MODDIR/.charging.sump" "$MODDIR/.charging.maxp" \
      "$MODDIR/.charging.np" 2>/dev/null || true

exit 0
