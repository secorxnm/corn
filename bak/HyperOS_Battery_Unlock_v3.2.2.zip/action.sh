#!/system/bin/sh

MODDIR=$(dirname "$0")
[ -z "$MODDIR" ] && MODDIR="."
# 若脚本所在目录找不到 module.prop, 回退到模块安装路径
[ -f "$MODDIR/module.prop" ] || MODDIR="/data/adb/modules/hyperos_battery_unlock"
MODULE_PROP="$MODDIR/module.prop"
PERSIST_FLAG="$MODDIR/unlocked.flag"
FAKE_FLAG="$MODDIR/fake_enabled.flag"
CLOUD_FLAG="$MODDIR/cloud_disabled.flag"
REAL_CYCLE_FILE="$MODDIR/real_cycle"
LOG_FILE="$MODDIR/action.log"
COOLAPK_URL="https://www.coolapk.com/u/37786723"

# ---- v1.3 容量解锁相关 ----
CAP_FLAG="$MODDIR/cap_enabled.flag"          # 容量解锁开关
CAP_FILE="$MODDIR/cap_value"                 # 目标容量值 (mAh)
VOLT_FLAG="$MODDIR/volt_enabled.flag"        # 截止电压开关
CLOUD_MODE_FILE="$MODDIR/cloud_mode"        # 云控策略: full=禁用+清数据 / clear=只清数据 / off=不管
CHARGE_LOG="$MODDIR/charge_log.jsonl"       # 充电采样记录(供 WebUI 画曲线)
# 采样开关: 此前只在使用处引用却从未赋值, 一直是空字符串,
# 导致 touch "" 失败、记录功能永远开不了。这就是"电池记录不生效"的根因。
CHARGE_LOG_FLAG="$MODDIR/charge_log_enabled.flag"
SESSIONS="$MODDIR/charge_sessions.jsonl"    # 已结算充电会话
CHG_STATE="$MODDIR/.charging"
CHG_FROM="$MODDIR/.charging.from"
CHG_LAST="$MODDIR/.charging.last"
CHG_LASTT="$MODDIR/.charging.lastt"
CHG_SUMP="$MODDIR/.charging.sump"           # 功率累加(mW)
CHG_MAXP="$MODDIR/.charging.maxp"           # 峰值功率(mW)
CHG_NP="$MODDIR/.charging.np"               # 有效功率采样数
BACKUP_DIR="$MODDIR/backup"                  # 节点原值备份目录

log() { echo "$@"; }

# v1.3 充电增强节点

# 容量节点: 系统认定的当前满充容量 (单位 uAh)
CAP_FULL_NODES="
/sys/class/power_supply/battery/charge_full
/sys/class/power_supply/bms/charge_full
"
# 设计容量节点 (只读参考值, 用作恢复目标)
CAP_DESIGN_NODES="
/sys/class/power_supply/battery/charge_full_design
/sys/class/power_supply/bms/charge_full_design
"
# 充电截止电压节点 (单位 mV 或 uV, 按节点长度自动判定)
VOLT_NODES="
/sys/class/power_supply/battery/constant_charge_voltage_max
/sys/class/power_supply/battery/voltage_max
/sys/class/power_supply/main/constant_charge_voltage_max
/sys/class/power_supply/bms/voltage_max
"
# 设计截止电压节点 (只读参考)
VOLT_DESIGN_NODES="
/sys/class/power_supply/battery/voltage_max_design
/sys/class/power_supply/bms/voltage_max_design
/sys/class/power_supply/battery/constant_charge_voltage_max_design
"
# 充电电流上限节点 (单位 uA)
CURR_NODES="
/sys/class/power_supply/battery/constant_charge_current_max
/sys/class/power_supply/battery/current_max
/sys/class/power_supply/main/constant_charge_current_max
"

# ===== v3.0 关机电压 / 开机电压 =====
#
# 关机电压 = 电池电压低到该值时自动关机。调低能"多榨一点电",
#   但过低会造成电池过放 —— 过放是锂电池最不可逆的损伤之一,
#   可能导致电池鼓包、容量骤降甚至无法再充电。
# 开机电压 = 电压高于该值才允许开机。调低可在低电量下强行开机,
#   但过低会陷入"开机→立刻没电关机"的循环。
#
# 这两项是本模块风险最高的功能, 因此:
#   - 只提供预设安全档, 自定义需显式 --force
#   - 硬边界之外一律拒绝, 不接受任何绕过
#   - 任何操作都打印风险提示

# ===== v3.1 strategy-fg / subpmic 关机保护电压 =====
#
# 小米机型上真正的关机电压由两层共同决定:
#   vcutoff_sw = 软件关机电压 (系统层判断)
#   vcutoff_fw = 固件关机电压 (PMIC/计量芯片硬件保护)
#
# 只改 sw 不改 fw 等于没改 —— 固件会先在更高的电压把电断掉,
# 系统根本没机会用到 sw 设的低电压。所以这两层必须一起拉低。
#
# mca_qcom_subpmic_proxy 是高通子 PMIC 的代理节点, 它自己还有一路
# 关机保护电压, 同样要一并处理, 否则它是最后的兜底闸门。
#
# 路径做成候选列表: 不同机型挂载位置不同(power_supply 下可能是
# strategy-fg / bms/strategy-fg / battery/strategy-fg), 全列一遍。
VCUTOFF_NODES="
/sys/class/power_supply/strategy-fg/vcutoff_sw
/sys/class/power_supply/strategy-fg/vcutoff_fw
/sys/class/power_supply/bms/strategy-fg/vcutoff_sw
/sys/class/power_supply/bms/strategy-fg/vcutoff_fw
/sys/class/power_supply/battery/strategy-fg/vcutoff_sw
/sys/class/power_supply/battery/strategy-fg/vcutoff_fw
/sys/class/power_supply/mca_qcom_subpmic_proxy/vcutoff_sw
/sys/class/power_supply/mca_qcom_subpmic_proxy/vcutoff_fw
/sys/class/power_supply/mca_qcom_subpmic_proxy/shutdown_voltage
/sys/class/power_supply/mca_qcom_subpmic_proxy/vbat_shutdown
/sys/class/power_supply/mca_qcom_subpmic_proxy/voltage_min
/sys/class/power_supply/mca_qcom_subpmic_proxy/vcutoff
"

# 关机电压节点候选 (单位按节点值长度自动判定 mV/uV)
# 含 strategy-fg / subpmic 的软硬件关机电压
SHUTDOWN_V_NODES="
/sys/class/power_supply/battery/voltage_min
/sys/class/power_supply/bms/voltage_min
/sys/class/power_supply/battery/shutdown_voltage
/sys/class/power_supply/battery/vbat_shutdown
/sys/class/qcom-battery/shutdown_voltage
/sys/class/xm_power/fg_basic/shutdown_voltage
$VCUTOFF_NODES
"
# 开机电压节点候选
BOOT_V_NODES="
/sys/class/power_supply/battery/voltage_boot
/sys/class/power_supply/bms/voltage_boot
/sys/class/power_supply/battery/boot_voltage
/sys/class/power_supply/battery/poweron_voltage
/sys/class/qcom-battery/boot_voltage
/sys/class/xm_power/fg_basic/boot_voltage
"

# 硬边界 (mV): 超出一律拒绝, 不提供任何绕过方式
#
# 下限 2500: 这是锂电芯规格书普遍标注的放电终止电压, 再低就进入过放区。
#   v3.1 之前设的是 3000, 现按机型实测放开到 2500 —— 2.5V 是硬件极限,
#   能榨出最多电量, 但代价是电池循环寿命明显下降、低温下更容易直接趴窝。
#   再往下不再允许(不接受绕过), 因为那已经不是"用尽电量"而是"损伤电芯"。
SHUTDOWN_V_MIN=2500
# 关机电压上限 3600: 高于此值毫无意义(会在高电量就关机)
SHUTDOWN_V_MAX=3600
# 开机电压边界
BOOT_V_MIN=3000
BOOT_V_MAX=3700

# 安全上限: 截止电压绝对不可超过此值 (mV)
# qcom 平台硬件上限 4500mV, 超过有损坏电池与安全风险
VOLT_HARD_MAX=4500
# 充电电流上限 (uA) — 10A, 超过此值不写入
CURR_HARD_MAX=10000000

# 列出存在的节点 (过滤不存在的)
list_existing() {
    local n
    for n in $1; do
        [ -f "$SYS_ROOT$n" ] && echo "$SYS_ROOT$n"
    done
}

# 备份文件名: 去掉 SYS_ROOT 前缀后把 / 换成 _
backup_name() {
    local n="${1#$SYS_ROOT}"
    echo "$n" | sed 's|/|_|g'
}

# 备份节点原值 (只备份一次, 已有备份则跳过)
backup_node() {
    local node="$1" name val
    name=$(backup_name "$node")
    mkdir -p "$BACKUP_DIR" 2>/dev/null
    [ -f "$BACKUP_DIR/$name" ] && return 0
    # 保存原始字符串, 不能过滤字符
    #
    # 节点可能是 hex 形式(如 0xce4)。用 tr -cd '0-9' 过滤会把 'c'
    # 削掉变成 "04", 原值就被破坏了 —— 还原时写回 "04", 值完全不对
    # (实测 0xce4 还原后变成 04)。
    val=$(node_raw "$node")
    [ -n "$val" ] && echo "$val" > "$BACKUP_DIR/$name" 2>/dev/null
}

# 从备份读回节点原值
backup_get() {
    local node="$1" name
    name=$(backup_name "$node")
    [ -f "$BACKUP_DIR/$name" ] && cat "$BACKUP_DIR/$name" 2>/dev/null
}

# 安全写入节点: 备份 → chmod → 写入 → 读回验证 → 失败则回滚
# 返回 0=成功, 1=失败
safe_write_node() {
    local node="$1" val="$2" orig got
    [ -f "$node" ] || return 1
    orig=$(cat "$node" 2>/dev/null | tr -cd '0-9')
    backup_node "$node"
    # 节点常为 444, 不改权限写不进去
    chmod 644 "$node" 2>/dev/null || true
    echo "$val" > "$node" 2>/dev/null || true
    got=$(cat "$node" 2>/dev/null | tr -cd '0-9')
    if [ "$got" = "$val" ]; then
        return 0
    fi
    # 写入失败: 回滚原值
    [ -n "$orig" ] && echo "$orig" > "$node" 2>/dev/null || true
    return 1
}

# 恢复单个节点到备份值
restore_node() {
    local node="$1" orig got
    orig=$(backup_get "$node")
    [ -z "$orig" ] && return 1
    chmod 644 "$node" 2>/dev/null || true
    # 写回原始字符串(可能是 hex), 不做任何数值处理
    echo "$orig" > "$node" 2>/dev/null || true
    got=$(node_raw "$node")
    [ "$got" = "$orig" ] && return 0
    return 1
}

# 读取设计容量 (mAh), 找不到返回空
read_design_mah() {
    local n raw
    for n in $(list_existing "$CAP_DESIGN_NODES"); do
        raw=$(cat "$n" 2>/dev/null | tr -cd '0-9')
        if [ -n "$raw" ] && [ "$raw" != "0" ]; then
            # >5 位视为 uAh, 转 mAh
            [ ${#raw} -gt 5 ] && echo $((raw / 1000)) || echo "$raw"
            return 0
        fi
    done
}

# 读取当前满充容量 (mAh)
read_full_mah() {
    local n raw
    for n in $(list_existing "$CAP_FULL_NODES"); do
        raw=$(cat "$n" 2>/dev/null | tr -cd '0-9')
        if [ -n "$raw" ] && [ "$raw" != "0" ]; then
            [ ${#raw} -gt 5 ] && echo $((raw / 1000)) || echo "$raw"
            return 0
        fi
    done
}

# 读取截止电压 (mV), 自动识别 uV/mV
read_volt_mv() {
    local n raw
    for n in $(list_existing "$VOLT_NODES"); do
        raw=$(cat "$n" 2>/dev/null | tr -cd '0-9')
        if [ -n "$raw" ] && [ "$raw" != "0" ]; then
            # 6 位以上视为 uV (如 4400000), 转 mV; 4 位视为 mV (如 4400)
            if [ ${#raw} -ge 6 ]; then
                echo $((raw / 1000))
            else
                echo "$raw"
            fi
            return 0
        fi
    done
}

# 读取设计截止电压 (mV)
read_volt_design_mv() {
    local n raw
    for n in $(list_existing "$VOLT_DESIGN_NODES"); do
        raw=$(cat "$n" 2>/dev/null | tr -cd '0-9')
        if [ -n "$raw" ] && [ "$raw" != "0" ]; then
            [ ${#raw} -ge 6 ] && echo $((raw / 1000)) || echo "$raw"
            return 0
        fi
    done
}

# 云控组件
# 伪装失效的主因: 云控服务(joyose / powerkeeper / analytics)会周期性
# 把电池真实数据同步回来, 覆盖写入的循环数。禁用它们伪装才能保持。
CLOUD_COMPONENTS="
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
com.xiaomi.joyose
com.miui.analytics
"
# 需要清空数据的包 (清掉已缓存的云控配置)
# 自动流程会执行 pm clear 的包
#
# 这里刻意不放 com.xiaomi.joyose。
#
# pm clear 会清空整个应用的私有数据, 而 joyose 同时承载用户可见的设置:
# 游戏工具箱、充电提示音等。清掉之后即便卸载模块、把组件全部恢复,
# 这些设置也回不来了(数据删除不可逆) —— 这正是"卸载后充电提示音
# 还是失效"的真正原因, 与组件是否恢复无关。
#
# 所以: 自动流程只禁用 joyose 组件(可逆), 不动它的数据。
# 需要连数据一起清的情况, 用显式命令 action.sh clearpk。
CLOUD_CLEAR_PKGS="
com.miui.powerkeeper
com.miui.analytics
"

# 仅手动清理时才碰的包(会丢用户设置)
CLOUD_CLEAR_MANUAL="
com.xiaomi.joyose
"

# ============================================================
# 解容目标 (v1.4 重写)
#
# 此前只禁用 2 个写死的组件名, 而 com.miui.powercenter 这个包名在
# 多数机型上并不存在(真实包名是 com.miui.powerkeeper), 结果是:
# 命令失败 -> 被 || true 吞掉 -> 仍报告"已解除"。大量机型因此
# "解容失败"。
#
# 改为: 包名优先 + 组件兜底 + 逐手段尝试 + 实际验证。
# ============================================================

# A. 可整体禁用的包 (电量管理 / 云控 / 统计)
#    注: 不含 com.miui.securitycenter —— 整体禁用有卡开机风险,
#        它只走下面的组件级禁用。
# 注意: 这里不再列 com.miui.powerkeeper
#
# powerkeeper 是「电量与性能」应用本体, 设置里电量详情页的省电策略就是它提供的。
# 整包禁用会直接导致省电策略界面消失 —— 群友反馈的正是这个现象。
# 对它的处理降为组件级(见 PROTECTED_PKGS 与 CLOUD_COMPONENTS)。
LOCK_PACKAGES="
com.xiaomi.joyose
com.miui.analytics
com.miui.daemon
com.xiaomi.powerchecker
com.xiaomi.miservice
"

# 只做组件级处理的包: 绝不整包禁用, 也不限制其后台
#
# 这类包承载了用户可见的系统功能(省电策略页面等), 整包禁用代价过大。
# 受保护包: 绝不能整包禁用, 也尽量不动其核心组件
#
# com.miui.powerkeeper = 电量与性能
# com.miui.securitycenter = 手机管家
#
# 这两个包承载"电量详情 → 省电策略"界面。整包禁用或禁用 PowerSaveService
# 后, 该页面的省电策略选项会整个消失 —— 群友反馈的正是这个问题。
# 因此解容改走云控组件(CloudUpdate*) + joyose + 属性覆盖 + 清学习数据,
# 不再触碰这两个包的核心组件。
PROTECTED_PKGS="
com.miui.powerkeeper
com.miui.securitycenter
"

# 是否属于"只做组件级"的包
is_protected_pkg() {
    local t p
    p=$(pkg_of "$1")
    for t in $PROTECTED_PKGS; do
        [ "$(pkg_of "$t")" = "$p" ] && return 0
    done
    return 1
}

# B. 只能按组件禁用的 (整体禁用会影响系统稳定)
# 注意: 不再禁用 PowerSaveService。
# 它是"电量详情 → 省电策略"的提供者, 禁用后该页面策略选项会消失,
# 且卸载后不易恢复(群友反馈"卸载无效")。
# 解容改由云控组件 + 属性覆盖 + 清除学习数据完成, 效果不依赖它。
# 只禁用云控接收器/任务这类组件, 不动 PowerSaveService 与整包
LOCK_COMPONENTS="
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudControlService
com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
"

# 电池学习 / 云控数据目录
LEARN_DIRS="
/data/vendor/batteryantiaging
/data/system/battery_config
/data/misc/batteryantiaging
/data/system/cloud_battery_config
/data/system/battery_cloud_config
/data/misc/battery_cloud
"

# 取包名部分 (组件形式 "pkg/cls" -> "pkg")
pkg_of() { echo "${1%%/*}"; }

# 包是否安装
# 注意: 无法探测时返回 0(视为"可能存在")并继续尝试禁用。
# 否则一旦 pm list 异常或输出格式非预期, 所有目标都会被跳过,
# 解容彻底不生效 —— 这正是此前大量机型"解容失败"的成因之一。
# 包列表缓存
#
# pm list packages 会全量列举所有已安装包, 真机上一次要 1~3 秒。
# 之前 pkg_exists 每次调用都跑一遍, 而一次 action 里要调十几次,
# 光这一项就要二三十秒 —— 超过 KernelSU 的 action 超时上限,
# 管理器侧就显示"运行失败"(终端里没超时所以能跑完, 不易察觉)。
# 改为一次列举、多次查询。
PKG_CACHE=""
PKG_LOADED=0
DISABLED_CACHE=""
DISABLED_LOADED=0

pkg_load() {
    [ "$PKG_LOADED" = "1" ] && return 0
    PKG_CACHE=$(pm list packages 2>/dev/null)
    PKG_LOADED=1
    return 0
}
disabled_load() {
    [ "$DISABLED_LOADED" = "1" ] && return 0
    DISABLED_CACHE=$(pm list packages -d 2>/dev/null)
    DISABLED_LOADED=1
    return 0
}

pkg_exists() {
    local p
    p=$(pkg_of "$1")
    [ -z "$p" ] && return 1
    pkg_load
    [ -z "$PKG_CACHE" ] && return 0
    echo "$PKG_CACHE" | grep -qx "package:$p"
}

# 是否已处于禁用状态
is_disabled() {
    local p
    p=$(pkg_of "$1")
    disabled_load
    [ -z "$DISABLED_CACHE" ] && return 1
    echo "$DISABLED_CACHE" | grep -qx "package:$p"
}

# 尝试禁用: 依次用多种手段, 任一成功即返回 0
#   pm disable            —— 最直接, 但系统应用常被拒
#   pm disable-user --user 0 —— 社区验证在澎湃OS上更可靠
#   pm suspend            —— 最后兜底
try_disable() {
    local t="$1" u ok=0
    pm disable "$t" >/dev/null 2>&1 && { record_disabled "$t"; return 0; }
    case "$t" in
        */*)
        # 组件形式: 不做 disable-user, 更不能用 suspend 兜底。
        #   pm suspend 对组件名会退化成挂起整包, 会把省电策略界面一起干掉
        #   (群友反馈的"电量详情策略消失"就可能是这条路)。
        #   组件禁用失败就放弃, 绝不升级为整包操作。
        return 1 ;;
        *)
        # HyperOS 上受保护的系统应用需先进入维护模式才能 disable-user
        # 对所有用户都操作: 只做 user 0 时工作空间里的组件仍会运行
        maintenance_on
        for u in $(active_users); do
            pm disable-user --user "$u" "$t" >/dev/null 2>&1 && ok=1
        done
        maintenance_off
        [ "$ok" = "1" ] && { record_disabled "$t"; return 0; } ;;
    esac
    pm suspend "$t" >/dev/null 2>&1 && { record_disabled "$t"; return 0; }
    return 1
}

# ===== 禁用清单 =====
#
# 之前卸载用硬编码清单恢复, 与实际禁用的包对不上, 导致漏恢复:
# 模块禁用了 6 个包, 卸载脚本只恢复其中一部分, 于是"删了模块功能还是没了"
# (游戏工具箱依赖 joyose, 充电音效相关组件也在被禁之列)。
#
# 改为: 禁用成功时把包名记进清单, 恢复/卸载时按清单逐一还原。
# 这样"禁用过什么就恢复什么", 不会因为清单不同步而遗漏。
DISABLED_LIST="$MODDIR/disabled_pkgs.txt"

record_disabled() {
    local p
    p=$(pkg_of "$1")
    [ -z "$p" ] && return 0
    touch "$DISABLED_LIST" 2>/dev/null || return 0
    grep -qxF "$p" "$DISABLED_LIST" 2>/dev/null && return 0
    echo "$p" >> "$DISABLED_LIST" 2>/dev/null || true
    # 同步进内存缓存: 否则本次进程内后续 is_disabled 仍查不到,
    # 会对同一目标重复跑一遍 pm 操作(真机上每条零点几秒)。
    if [ "$DISABLED_LOADED" = "1" ]; then
        DISABLED_CACHE="$DISABLED_CACHE
package:$p"
    fi
}

unrecord_disabled() {
    local p
    p=$(pkg_of "$1")
    [ -f "$DISABLED_LIST" ] || return 0
    grep -vxF "$p" "$DISABLED_LIST" > "$DISABLED_LIST.tmp" 2>/dev/null && \
        mv "$DISABLED_LIST.tmp" "$DISABLED_LIST" 2>/dev/null || true
}

# 彻底恢复一个包 (解冻 joyose 等)
#
# 之前只做 pm enable, 不恢复 appops:
#   禁用时设置了 RUN_IN_BACKGROUND / RUN_ANY_IN_BACKGROUND = deny,
#   若恢复路径漏掉 appops, 包虽然 enabled 但仍无法后台运行,
#   表现为"解冻了却还是不正常"。
# 这里统一: 重置 appops 到默认 -> 解除挂起 -> 多形式 enable -> 校验
pkg_restore() {
    local t="$1" p
    p=$(pkg_of "$t")

    # 1. 重置所有 appops 到默认(比逐个 allow 更彻底, 不会漏项)
    cmd appops reset "$p" >/dev/null 2>&1 || true
    # 个别 rom 的 reset 不支持包名, 退回逐个 allow
    cmd appops set "$p" RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true
    cmd appops set "$p" RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true

    # 2. 解除挂起
    pm unsuspend "$p" >/dev/null 2>&1 || true

    # 3. 多形式 enable(组件/包, 对所有用户)
    maintenance_on
    for u in $(active_users); do
        pm enable --user "$u" "$p" >/dev/null 2>&1 || true
        pm enable --user "$u" "$t" >/dev/null 2>&1 || true
    done
    maintenance_off
    pm enable "$t" >/dev/null 2>&1 || true
    pm enable "$p" >/dev/null 2>&1 || true

    # 常规手段仍失败时走兜底, 否则包会一直卡在禁用状态
    # 表现为"云控怎么都恢复不了"
    if pkg_still_disabled "$p"; then
        restore_install_existing "$p"
        restore_via_restrictions "$p"
    fi
    return 0
}

# ===== 恢复兜底 =====
#
# pm enable 在部分机型上会失败(SecurityException / 受保护系统应用),
# 此时包会一直卡在禁用状态, 表现为"云控怎么都恢复不了"。
# 这里提供两条兜底路径。

# 兜底 1: 恢复被 uninstall -k --user 0 移除的系统应用
# (本模块不使用 uninstall, 但若用户此前用过其他工具, 这条能救回来)
restore_install_existing() {
    local p u
    p=$(pkg_of "$1")
    for u in $(active_users); do
        pm install-existing --user "$u" "$p" >/dev/null 2>&1 || true
    done
    return 0
}

# 兜底 2: 直接改包状态记录文件
#
# /data/system/users/<uid>/package-restrictions.xml 保存各包的启用状态,
# enabled="1" 正常, "2"/"3"/"4" 为各类禁用。系统启动时读取。
# 注意: Android 12+ 该文件可能是 abx 二进制格式, 不能文本替换,
#       故只在处理前检测是否为文本 XML, 否则跳过(避免写坏文件)。
restore_via_restrictions() {
    local p="$1" f found=0 head
    for f in /data/system/users/*/package-restrictions.xml \
             "${SYS_ROOT}"/data/system/users/*/package-restrictions.xml; do
        [ -f "$f" ] || continue
        # abx 二进制格式检测: 文本 XML 以 <?xml 开头
        head=$(head -c 5 "$f" 2>/dev/null)
        [ "$head" = "<?xml" ] || continue
        grep -q "name=\"$p\"" "$f" 2>/dev/null || continue
        cp "$f" "$f.bak" 2>/dev/null || continue
        # 只改目标包那一行, 不用全局替换, 避免影响其他包
        awk -v pkg="$p" '
            {
                if (match($0, "name=\"" pkg "\"")) {
                    gsub(/enabled="[234]"/, "enabled=\"1\"")
                    gsub(/enabled-caller="[^"]*"/, "enabled-caller=\"\"")
                }
                print
            }' "$f" > "$f.tmp" 2>/dev/null && mv "$f.tmp" "$f" 2>/dev/null || true
        chmod 660 "$f" 2>/dev/null || true
        found=1
    done
    [ "$found" = "1" ]
}

# 按清单恢复所有被本模块禁用的包
#
# 这是"删除模块后功能还在"问题的根治点: 不再依赖硬编码清单,
# 而是按实际记录还原, 一个都不漏。
restore_all_recorded() {
    local p left=""; local n=0; local snap
    [ -f "$DISABLED_LIST" ] || return 0
    # 必须先快照再遍历: 循环内 unrecord_disabled 会重写同一个文件,
    # 边读边写会导致行错位/漏读 —— 这正是"云控一直恢复不了"的原因之一,
    # 部分包根本没被遍历到, 清单因而永远清不干净。
    snap="$DISABLED_LIST.snap"
    cp "$DISABLED_LIST" "$snap" 2>/dev/null || return 0
    while read -r p; do
        [ -z "$p" ] && continue
        pkg_exists "$p" || { unrecord_disabled "$p"; continue; }
        pkg_restore "$p"
        n=$((n + 1))
        if pkg_still_disabled "$p"; then
            left="$left $p"
        else
            unrecord_disabled "$p"
        fi
    done < "$snap"
    rm -f "$snap" 2>/dev/null || true
    # 全部恢复成功则删除清单
    if [ ! -s "$DISABLED_LIST" ]; then
        rm -f "$DISABLED_LIST" 2>/dev/null || true
    fi
    if [ -n "$left" ]; then
        log "警告: 以下组件仍为禁用状态, 请在应用设置中手动启用:$left"
        return 1
    fi
    [ "$n" -gt 0 ] && return 0
    return 0
}

# 恢复结果校验: 仍被禁用则返回 1
pkg_still_disabled() {
    pm list packages -d 2>/dev/null | grep -qx "package:$(pkg_of "$1")"
}

# 尝试恢复: 与 try_disable 对应
try_enable() {
    local t="$1" u
    case "$t" in
        */*) : ;;
        *) pm unsuspend "$t" >/dev/null 2>&1 || true
           maintenance_on
           for u in $(active_users); do
               pm enable --user "$u" "$t" >/dev/null 2>&1 || true
           done
           maintenance_off ;;
    esac
    pm enable "$t" >/dev/null 2>&1 || true
    return 0
}

# 循环次数节点候选
# 不同机型/内核路径差异很大, 这里列出已知路径, 全部尝试写入,
# 而不是只写第一个找到的 —— 只写一个常因该节点只读而静默失败。
CYCLE_NODES="
/sys/class/qcom-battery/fake_cycle
/sys/class/xm_power/fg_master/cyclecount
/sys/class/xm_power/cyclecount
/sys/class/power_supply/battery/cycle_count
/sys/class/power_supply/battery/fg_cycle_count
/sys/class/power_supply/battery/batt_cycle_count
/sys/class/power_supply/bms/cycle_count
"

# 输出所有存在的循环节点
# 扫描 sysfs 发现更多循环节点(不依赖硬编码清单)
#
# 硬编码清单覆盖不到的机型, 这里做兜底: 遍历 power_supply 与常见电量计
# 目录下名字含 cycle 的可读节点。这样新机型不必等模块更新就能用。
cycle_scan() {
    local d f
    for d in "$SYS_ROOT"/sys/class/power_supply/*/ \
             "$SYS_ROOT"/sys/class/qcom-battery/ \
             "$SYS_ROOT"/sys/class/xm_power/ \
             "$SYS_ROOT"/sys/class/xm_power/fg_master/ \
             "$SYS_ROOT"/sys/class/bms/; do
        [ -d "$d" ] || continue
        for f in "$d"*cycle* "$d"*Cycle*; do
            [ -f "$f" ] || continue
            # 只读节点也返回: 写入时会被验证排除, 但可作为读数来源
            echo "$f"
        done
    done
}

# 合并: 硬编码清单 + 扫描结果, 去重
all_cycle_nodes() {
    local n
    {
        find_cycle_nodes
        cycle_scan
    } | while read -r n; do echo "$n"; done | awk '!seen[$0]++'
}

# Root 方案检测: 不同方案的模块路径与可用命令不同
root_flavor() {
    if [ -d /data/adb/ksu ] || [ -n "$KSU" ]; then echo "kernelsu"
    elif [ -d /data/adb/ap ] || [ -n "$APATCH" ]; then echo "apatch"
    elif [ -d /data/adb/magisk ]; then echo "magisk"
    else echo "unknown"; fi
}

# 当前活跃用户列表(多用户 / 工作空间兼容)
#
# 只对 user 0 操作时, 工作空间或副用户里的同名组件仍在运行,
# 云控可能从其他用户空间重新拉起。这里对所有已解锁用户都操作一遍。
active_users() {
    local u
    u=$(pm list users 2>/dev/null | grep -oE '\{[0-9]+' | tr -d '{')
    [ -z "$u" ] && u=0
    echo "$u"
}

# 工具可用性检测: 某些精简 ROM 缺 cmd / settings, 缺了就跳过而不是报错
have_cmd() {
    command -v settings >/dev/null 2>&1 && command -v cmd >/dev/null 2>&1
}

# 维护模式权限: 部分机型 pm disable-user / enable 需要它才能成功
#
# HyperOS 上直接执行 pm disable-user --user 0 com.miui.powerkeeper 会失败,
# 需先设置 maintenance_mode_user_id 才能操作受保护的系统应用。
# 用完必须清除, 否则系统会一直停留在维护模式。
maintenance_on() {
    have_cmd || return 0
    settings put global maintenance_mode_user_id 110 >/dev/null 2>&1 || true
}
maintenance_off() {
    have_cmd || return 0
    settings delete global maintenance_mode_user_id >/dev/null 2>&1 || true
}

find_cycle_nodes() {
    for n in $CYCLE_NODES; do
        [ -f "$SYS_ROOT$n" ] && echo "$SYS_ROOT$n"
    done
}

# 写循环值到所有可用节点, 成功写入的路径记入 CYCLE_OK_NODES
write_all_cycle_nodes() {
    local val="$1" n got
    CYCLE_OK_NODES=""
    CYCLE_FAIL_NODES=""
    for n in $(all_cycle_nodes); do
        chmod 666 "$n" 2>/dev/null || true
        echo "$val" > "$n" 2>/dev/null || true
        # 读回验证: 节点可能只读, 写不进去却不报错, 只看返回码会误判成功
        got=$(cat "$n" 2>/dev/null | tr -cd '0-9')
        if [ -n "$got" ] && [ "$got" = "$val" ]; then
            CYCLE_OK_NODES="${CYCLE_OK_NODES:+$CYCLE_OK_NODES }$n"
        else
            CYCLE_FAIL_NODES="${CYCLE_FAIL_NODES:+$CYCLE_FAIL_NODES }$n"
        fi
    done
    [ -n "$CYCLE_OK_NODES" ]
}

# sysfs 根目录: 默认 /sys, 测试时可设为 mock 目录
SYS_ROOT="${SYS_ROOT:-}"

# 电池节点探测: 兼容 battery / battery0 / Battery / bms
# 用法: find_node "文件名"
find_node() {
    for base in battery battery0 Battery bms; do
        [ -f "$SYS_ROOT/sys/class/power_supply/$base/$1" ] && { echo "$SYS_ROOT/sys/class/power_supply/$base/$1"; return; }
    done
}

# 采集电池信息, 结果存入全局变量
collect_info() {
    BAT=""
    for p in battery battery0 Battery; do
        [ -d "$SYS_ROOT/sys/class/power_supply/$p" ] && { BAT="$SYS_ROOT/sys/class/power_supply/$p"; break; }
    done
    if [ -z "$BAT" ]; then
        for d in "$SYS_ROOT"/sys/class/power_supply/*/; do
            [ -f "${d}charge_full" ] && { BAT="${d%/}"; break; }
        done
    fi
    [ -z "$BAT" ] && BAT="$SYS_ROOT/sys/class/power_supply/battery"

    # 设计容量 / 当前满充容量: 优先 uAh(charge_full), 兼容 mAh(energy_full)
    NODE_DESIGN=$(find_node "charge_full_design")
    [ -z "$NODE_DESIGN" ] && NODE_DESIGN=$(find_node "energy_full_design")
    NODE_FULL=$(find_node "charge_full")
    [ -z "$NODE_FULL" ] && NODE_FULL=$(find_node "energy_full")

    DESIGN=5000
    if [ -n "$NODE_DESIGN" ]; then
        raw=$(cat "$NODE_DESIGN" 2>/dev/null | tr -cd '0-9')
        raw=${raw:-0}
        # 大于 5 位视为 uAh, 转为 mAh
        [ ${#raw} -gt 5 ] && DESIGN=$((raw / 1000)) || DESIGN=$raw
    fi
    [ "$DESIGN" -eq 0 ] && DESIGN=$(getprop ro.battery.capacity 2>/dev/null || echo 5000)

    CURRENT=$DESIGN
    if [ -n "$NODE_FULL" ]; then
        raw=$(cat "$NODE_FULL" 2>/dev/null | tr -cd '0-9')
        raw=${raw:-0}
        [ ${#raw} -gt 5 ] && CURRENT=$((raw / 1000)) || CURRENT=$raw
    fi
    [ "$CURRENT" -eq 0 ] && CURRENT=$DESIGN

    HEALTH=$(awk -v c="$CURRENT" -v d="$DESIGN" 'BEGIN{printf "%.2f", (d>0?c/d:1)*100}')

    CYCLE=0
    for f in cycle_count batt_cycle_count batt_charge_cycles; do
        if [ -f "$BAT/$f" ]; then
            CYCLE=$(cat "$BAT/$f" 2>/dev/null | tr -cd '0-9')
            break
        fi
    done
    CYCLE=${CYCLE:-0}
    [ "$CYCLE" -gt 0 ] && CYCLE_STR="$CYCLE 次" || CYCLE_STR="不支持读取"

    # 节点不存在时应显示 "?" 而不是算成 0.0
    # (此前 awk 对空值按 0 处理, 缺失节点会显示 "0.0 ℃" / "0.00 V")
    CAP="?"
    [ -f "$BAT/capacity" ] && CAP=$(cat "$BAT/capacity" 2>/dev/null)
    [ -z "$CAP" ] && CAP="?"

    TEMP="?"
    if [ -f "$BAT/temp" ]; then
        TEMP=$(awk -v t="$(cat "$BAT/temp" 2>/dev/null)" 'BEGIN{printf "%.1f", t/10}')
        [ -z "$TEMP" ] && TEMP="?"
    fi

    VOLT="?"
    if [ -f "$BAT/voltage_now" ]; then
        VOLT=$(awk -v v="$(cat "$BAT/voltage_now" 2>/dev/null)" 'BEGIN{printf "%.2f", v/1000000}')
        [ -z "$VOLT" ] && VOLT="?"
    fi
    case "$(cat "$BAT/status" 2>/dev/null)" in
        Discharging) SCN="放电中" ;;
        Charging)    SCN="充电中" ;;
        Full)        SCN="已充满" ;;
        "Not charging") SCN="未充电" ;;
        *)           SCN="未知" ;;
    esac
}

# 信息面板
LINE="======================================"
SUBLINE="--------------------------------------"

# 输出对齐的一行: kv "标签" "值" "标签显示宽度"
# 显示宽度: 一个汉字 = 2 列。对齐目标 10 列。
#   "云控" = 4, "健康度" = 6, "解除限制"/"设计容量" = 8
kv() {
    local label="$1" val="$2" w="${3:-8}" pad="" need
    need=$((10 - w))
    while [ "$need" -gt 0 ]; do
        pad=" $pad"
        need=$((need - 1))
    done
    log "  ${label}${pad}${val}"
}

print_status_block() {
    log "  [ 模块状态 ]"
    if [ -f "$PERSIST_FLAG" ]; then
        kv "解除限制" "已开启" 8
    else
        kv "解除限制" "未开启" 8
    fi
    if [ -f "$FAKE_FLAG" ]; then
        kv "循环伪装" "已开启 ($(cat "$MODDIR/fake_value" 2>/dev/null || echo ?) 次)" 8
    else
        kv "循环伪装" "未开启" 8
    fi
    if [ -f "$CLOUD_FLAG" ]; then
        kv "云控" "已禁用" 4
    else
        kv "云控" "未禁用" 4
    fi
    # 附加项仅开启时显示, 未开启不占行(避免"未解锁"造成困惑)
    [ -f "$CAP_FLAG" ] && kv "容量解锁" "已开启 ($(cat "$CAP_FILE" 2>/dev/null) mAh)" 8
    [ -f "$VOLT_FLAG" ] && kv "截止电压" "已解锁" 8
    kv "守护进程" "$(service_running && echo 运行中 || echo 未运行)" 8
    # 只显示, 不修改。让用户能确认模块没有动过 SELinux
    kv "SELinux" "$(selinux_state)" 8
}

print_battery_block() {
    collect_info
    log "  [ 电池信息 ]"
    kv "机型" "$(device_name)" 4
    kv "电量" "${CAP}%" 4
    kv "状态" "$SCN" 4
    kv "温度" "${TEMP} ℃" 4
    kv "电压" "${VOLT} V" 4
    kv "设计容量" "${DESIGN} mAh" 8
    kv "当前容量" "${CURRENT} mAh" 8
    # 释放比例: 当前容量占设计容量的百分比, 直观反映被锁了多少
    if [ -n "$DESIGN" ] && [ -n "$CURRENT" ] && [ "$DESIGN" -gt 0 ]; then
        kv "释放比例" "$((CURRENT * 100 / DESIGN))%" 8
    fi
    kv "健康度" "${HEALTH}%" 6
    # 实时充电功率 = 电压 × 电流 (仅充电时显示)
    local pw
    pw=$(charge_power)
    [ -n "$pw" ] && kv "充电功率" "$pw" 8
    if [ -f "$FAKE_FLAG" ]; then
        kv "循环次数" "${CYCLE_STR} (已伪装)" 8
    else
        kv "循环次数" "${CYCLE_STR}" 8
    fi
}

# 实时充电功率: 电压(V) × 电流(A) = W
# 电流取 current_now(放电为负/充电为正, 各机型符号约定不同, 取绝对值)
# 未充电或无节点时返回空
charge_power() {
    local bat cur_ua vol_uv w
    bat=""
    for p in battery battery0 Battery; do
        [ -d "$SYS_ROOT/sys/class/power_supply/$p" ] && { bat="$SYS_ROOT/sys/class/power_supply/$p"; break; }
    done
    [ -z "$bat" ] && return 0
    # 未在充电则不显示
    case "$(cat "$bat/status" 2>/dev/null)" in
        Charging|Full) ;;
        *) return 0 ;;
    esac
    cur_ua=$(cat "$bat/current_now" 2>/dev/null | tr -cd '0-9')
    [ -z "$cur_ua" ] && return 0
    vol_uv=$(cat "$bat/voltage_now" 2>/dev/null | tr -cd '0-9')
    [ -z "$vol_uv" ] && return 0
    # 功率(W) = uA/1000000 × uV/1000000 = uA*uV/1e12
    # 用 awk 避免整数溢出
    w=$(awk -v c="$cur_ua" -v v="$vol_uv" 'BEGIN{printf "%.1f", (c/1000000)*(v/1000000)}')
    [ -z "$w" ] && return 0
    echo "${w} W"
}

# SELinux 状态
selinux_state() {
    if [ -f "$SYS_ROOT/sys/fs/selinux/enforce" ]; then
        if [ "$(cat "$SYS_ROOT/sys/fs/selinux/enforce" 2>/dev/null)" = "1" ]; then
            echo "Enforcing"
        else
            echo "Permissive"
        fi
        return 0
    fi
    if command -v getenforce >/dev/null 2>&1; then
        local s
        s=$(getenforce 2>/dev/null)
        [ -n "$s" ] && { echo "$s"; return 0; }
    fi
    echo "未知"
}

# SELinux 命令: 查看 / 手动恢复 Enforcing
do_selinux() {
    local st mode="${1:-}"
    st=$(selinux_state)
    case "$mode" in
        enforce|on|1)
            if [ -f "$SYS_ROOT/sys/fs/selinux/enforce" ]; then
                echo 1 > "$SYS_ROOT/sys/fs/selinux/enforce" 2>/dev/null || true
            else
                setenforce 1 2>/dev/null || true
            fi
            log "SELinux: $(selinux_state)"
            return 0
            ;;
        "")
            log "SELinux: $st"
            [ "$st" = "Permissive" ] && log "本模块不修改此项, 重启可恢复; 或: action.sh selinux enforce"
            return 0
            ;;
        *)
            log "用法: action.sh selinux [enforce]"
            return 0
            ;;
    esac
}

# 机型名: 优先市场名(用户认识的"小米15"), 再型号, 最后设备代号兜底
# 只用 ro.product.device 会显示 xiaomi15/shennong 这类内部代号, 用户看不懂
device_name() {
    local n
    for p in ro.product.marketname ro.product.model ro.product.name ro.product.device; do
        n=$(getprop "$p" 2>/dev/null)
        [ -n "$n" ] && break
    done
    [ -z "$n" ] && n="未知"
    echo "$n"
}

# 守护进程是否在运行 (不依赖 pgrep, 部分设备没有)
service_running() {
    local f p
    for f in "$MODDIR/.service.pid"; do
        [ -f "$f" ] || continue
        p=$(cat "$f" 2>/dev/null)
        [ -n "$p" ] && [ -d "/proc/$p" ] && return 0
    done
    command -v pgrep >/dev/null 2>&1 && \
        pgrep -f 'hyperos_battery_unlock/service.sh' >/dev/null 2>&1 && return 0
    return 1
}

# 确保守护进程在运行
# 场景: 用户在管理器里点操作改了配置, 但守护此前因"无任务"已退出,
#       若不拉起, 伪装值只能等下次重启才被维持。
ensure_daemon() {
    service_running && return 0
    [ -x "$MODDIR/service.sh" ] || return 0
    # 脱离当前终端启动, 避免随 action 执行结束被回收
    ( sh "$MODDIR/service.sh" >/dev/null 2>&1 < /dev/null & ) 2>/dev/null
    sleep 1
}

print_panel() {
    log ""
    log "$LINE"
    log "   解除锁容  v3.2.2"
    log "$LINE"
    log ""
    print_status_block
    log ""
    print_battery_block
    log ""
    log "$SUBLINE"
    log "  作者: 浔念6"
    log "  酷安: https://www.coolapk.com/u/37786723"
    log ""
}

# 兼容旧调用
print_info() {
    print_panel
}

# 把电池信息写入 module.prop 的 description
# 用 awk 重写, 避免 sed 遇到特殊字符崩溃
# 格式: 基础描述 [健康度:xx%] [循环:xx次] [状态:...]
update_prop_desc() {
    collect_info
    [ -f "$MODULE_PROP" ] || return 1

    LOCK_TAG=""
    [ -f "$PERSIST_FLAG" ] && LOCK_TAG="已解除限制" || LOCK_TAG="默认"
    FAKE_TAG=""
    [ -f "$FAKE_FLAG" ] && FAKE_TAG="开" || FAKE_TAG="关"
    CLOUD_TAG=""
    [ -f "$CLOUD_FLAG" ] && CLOUD_TAG="禁" || CLOUD_TAG="开"

    # 基础描述 (去除已有的动态标签, 保持干净)
    BASE=$(grep "^description=" "$MODULE_PROP" | head -n1 | cut -d'=' -f2-)
    BASE=$(echo "$BASE" | sed -E \
        's/ \[健康度:[0-9.]+\%\]//g;
         s/ \[循环:[^]]*\]//g;
         s/ \[状态:[^]]*\]//g;
         s/ \[伪装:[^]]*\]//g;
         s/ \[云控:[^]]*\]//g' | sed 's/  */ /g' | xargs)

    NEW_DESC="${BASE} [健康度:${HEALTH}%] [循环:${CYCLE_STR}] [状态:${LOCK_TAG}] [伪装:${FAKE_TAG}] [云控:${CLOUD_TAG}]"

    # awk 原地改写 description 行
    awk -v line="description=${NEW_DESC}" '
        BEGIN { done=0 }
        /^description=/ {
            if (!done) { print line; done=1; next }
        }
        { print }
    ' "$MODULE_PROP" > "$MODULE_PROP.tmp" && mv "$MODULE_PROP.tmp" "$MODULE_PROP"

    # 不打印完整描述: 内容很长, 会破坏 action 输出窗口的排版
    # 需要查看时用 action.sh status 或直接在管理器模块页面看
}

# 解除充电限制
do_unlock() {
    local ok=0 total=0 t

    # 不同机型控制充电上限的属性名不一样, 全部覆盖一遍
    # v3.0 扩充: 加入 vendor 系与多个命名变体, 覆盖更多机型
    for prop in persist.sys.charging_stop_level \
                persist.sys.battery.charging_stop \
                persist.vendor.battery.charging_stop_level \
                persist.sys.bms.charging_stop_level \
                persist.vendor.bms.charging_stop_level \
                persist.sys.battery.charge_limit \
                persist.sys.charge_stop_level \
                vendor.battery.charging_stop_level; do
        resetprop -n "$prop" 100 2>/dev/null || true
    done
    # 老化锁容相关属性一并清掉
    for prop in persist.sys.bms.aging_lock \
                persist.sys.batteryantiaging.enabled \
                persist.vendor.bms.aging_lock; do
        resetprop -n "$prop" 0 2>/dev/null || true
    done
    # resetprop 不可用时(非 Magisk 环境)退回 setprop / settings
    if ! command -v resetprop >/dev/null 2>&1; then
        setprop persist.sys.charging_stop_level 100 2>/dev/null || true
    fi
    # settings 三个命名空间都写: 不同机型读的位置不同
    for ns in global secure system; do
        settings put "$ns" charging_stop_level 100 >/dev/null 2>&1 || true
        settings put "$ns" battery_charge_limit 100 >/dev/null 2>&1 || true
    done

    # 1. 组件级禁用 (securitycenter 等, 整体禁用有风险)
    for t in $LOCK_COMPONENTS; do
        pkg_exists "$t" || continue
        is_disabled "$t" && { ok=$((ok+1)); total=$((total+1)); continue; }
        total=$((total+1))
        try_disable "$t" && ok=$((ok+1))
    done

    # 2. 包名级禁用
    #
    # 受保护包(powerkeeper=电量与性能)不能整包禁用:
    #   省电策略界面就在这个应用里, 整包禁用会让"电量详情"页面的
    #   省电策略选项整个消失 —— 这是用户反馈过的问题。
    #   对这类包只做组件级禁用(见 LOCK_COMPONENTS), UI 与用户配置都保留。
    for t in $LOCK_PACKAGES; do
        pkg_exists "$t" || continue
        if is_protected_pkg "$t"; then
            log "  跳过整包禁用: $(pkg_of "$t") (受保护, 保留省电策略界面)"
            continue
        fi
        is_disabled "$t" && { ok=$((ok+1)); total=$((total+1)); continue; }
        total=$((total+1))
        try_disable "$t" && ok=$((ok+1))
    done

    # 3. 清除电池学习 / 云控数据
    for d in $LEARN_DIRS; do
        [ -d "$d" ] && rm -rf "$d"/* >/dev/null 2>&1 || true
    done

    # 强制停止仍在运行的电池/云控进程: 组件被禁用后旧进程还会继续
    # 施加限制, 直到系统重启它为止。主动杀掉能让解容立即生效。
    for p in com.xiaomi.joyose com.miui.analytics com.xiaomi.powerchecker \
             com.miui.daemon com.xiaomi.miservice; do
        pkg_exists "$p" || continue
        am force-stop "$p" >/dev/null 2>&1 || true
    done

    touch "$PERSIST_FLAG" 2>/dev/null || true
    do_cloud_disable
    ensure_daemon

    # 报告真实结果, 不再无条件报成功
    if [ "$ok" -gt 0 ]; then
        log "已解除充电限制 (禁用 $ok/$total 项)"
    else
        log "未找到可禁用目标, 已清除学习数据"
        log "该机型可能需其他方式, 可执行 action.sh diag"
    fi
}

# 恢复系统默认
do_restore() {
    local t left=""
    # 先按实际禁用清单还原(根治漏恢复), 再遍历已知清单兜底
    restore_all_recorded || true
    for t in $LOCK_COMPONENTS $LOCK_PACKAGES; do
        pkg_exists "$t" || continue
        pkg_restore "$t"
    done
    # 校验: 仍有包处于禁用状态时列出, 便于排查"解冻失败"
    for t in $LOCK_PACKAGES; do
        pkg_exists "$t" || continue
        pkg_still_disabled "$t" && left="$left $(pkg_of "$t")"
    done
    [ -n "$left" ] && log "警告: 以下组件仍为禁用状态, 可在应用设置中手动启用:$left"
    for prop in persist.sys.charging_stop_level \
                persist.sys.battery.charging_stop \
                persist.vendor.battery.charging_stop_level \
                persist.sys.bms.charging_stop_level; do
        resetprop -n "$prop" 80 2>/dev/null || true
    done
    settings delete global charging_stop_level >/dev/null 2>&1 || true
    rm -f "$PERSIST_FLAG"

    # 关闭伪装并还原真实循环数 (若之前备份过)
    if [ -f "$FAKE_FLAG" ]; then
        real=$(cat "$REAL_CYCLE_FILE" 2>/dev/null | tr -cd '0-9')
        if [ -n "$real" ]; then
            write_all_cycle_nodes "$real" >/dev/null 2>&1 || true
            log "循环次数已还原为真实值: ${real}"
        fi
        rm -f "$FAKE_FLAG" "$MODDIR/fake_value" "$REAL_CYCLE_FILE" 2>/dev/null
        log "循环伪装已关闭。"
    fi

    # v1.3: 还原容量解锁与截止电压
    if [ -f "$CAP_FLAG" ]; then
        do_cap_off >/dev/null 2>&1 || true
        log "容量解锁已还原。"
    fi
    if [ -f "$VOLT_FLAG" ]; then
        do_volt_off >/dev/null 2>&1 || true
        log "截止电压已还原。"
    fi

    do_cloud_enable
    log "已恢复系统默认电量管理 (含云控组件)。"
}

# 禁用云控组件 + 清空云控数据
# 读取当前云控策略 (默认 full)
cloud_mode() {
    local m
    m=$(cat "$CLOUD_MODE_FILE" 2>/dev/null | tr -cd 'a-z')
    case "$m" in
        full|clear|off) : ;;
        *) m="full" ;;
    esac
    echo "$m"
}

set_cloud_mode() {
    echo "$1" > "$CLOUD_MODE_FILE" 2>/dev/null || true
}

# 按当前策略应用云控处理
#   full  = 禁用组件 + 清数据
#   clear = 只清数据 (保留云控组件可用, 适合想用云控功能的用户)
#   off   = 完全不管 (只靠循环伪装)
# 强化禁用: 常规手段之后, 再停止运行并禁止后台
# 云控常通过常驻服务/Job 重新拉起, 只 pm disable 不够
cloud_hard_disable() {
    local t="$1" p
    p=$(pkg_of "$t")
    # 受保护包(如 powerkeeper): 只处理传入的组件, 不整包禁用、不限后台。
    # 整包禁用会让省电策略界面消失; 限后台会让其服务异常。
    if is_protected_pkg "$p"; then
        case "$t" in
            */*) try_disable "$t" || true ;;
            *)   return 0 ;;   # 传入的是整包名, 直接跳过
        esac
        return 0
    fi
    try_disable "$t" || true
    am force-stop "$p" >/dev/null 2>&1 || true
    cmd appops set "$p" RUN_IN_BACKGROUND deny >/dev/null 2>&1 || true
    cmd appops set "$p" RUN_ANY_IN_BACKGROUND deny >/dev/null 2>&1 || true
}

# 恢复云控时的反向操作
cloud_hard_enable() {
    local t="$1" p
    p=$(pkg_of "$t")
    try_enable "$p"
    cmd appops set "$p" RUN_IN_BACKGROUND allow >/dev/null 2>&1 || true
    cmd appops set "$p" RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1 || true
}

# 关闭云控后的收尾: 重新伪装循环 + 清除电池数据
# 云控运行期间可能已把真实循环值写回、并缓存了电池策略,
# 关掉后必须重刷一次, 否则伪装"看起来没生效"
cloud_post_action() {
    local v d
    if [ -f "$FAKE_FLAG" ]; then
        v=$(cat "$MODDIR/fake_value" 2>/dev/null | tr -cd '0-9')
        if [ -n "$v" ]; then
            write_all_cycle_nodes "$v" >/dev/null 2>&1 || true
        fi
    fi
    for d in $LEARN_DIRS; do
        [ -d "$d" ] && rm -rf "$d"/* >/dev/null 2>&1 || true
    done
}

do_cloud_disable() {
    local mode c
    mode=$(cloud_mode)

    case "$mode" in
        off)
            rm -f "$CLOUD_FLAG" 2>/dev/null
            return 0
            ;;
        clear)
            # 只清数据, 不动组件
            # 受保护包默认不清: pm clear 会连用户的省电策略配置一起清掉,
            #   清完即使组件还在, 用户看到的也是"策略没了"。
            #   需要彻底清除可手动执行 action.sh clearpk
            for c in $CLOUD_CLEAR_PKGS; do
                pkg_exists "$c" || continue
                if is_protected_pkg "$c"; then
                    log "  跳过清数据: $(pkg_of "$c") (受保护, 避免丢失省电策略)"
                    continue
                fi
                pm clear "$c" >/dev/null 2>&1 || true
            done
            rm -f "$CLOUD_FLAG" 2>/dev/null
            return 0
            ;;
    esac

    # full: 强化禁用组件 + 清数据
    #
    # 说明: 这里不按"已禁用就跳过"来省时间。
    # pm disable 对已禁用的目标是幂等的, 单次零点几秒, 而云控组件
    # 可能被系统重新拉起, 每次点击都重新压制一次更可靠。
    # 真正的耗时大头是 pm list packages(全量列举), 已由上面的缓存解决。
    for c in $CLOUD_COMPONENTS; do
        pkg_exists "$c" || continue
        cloud_hard_disable "$c"
    done
    # 包名级兜底: 组件名可能已变, 但包名稳定
    # 受保护包跳过整包禁用(只清数据), 否则省电策略界面会消失
    for c in $CLOUD_CLEAR_PKGS; do
        pkg_exists "$c" || continue
        if is_protected_pkg "$c"; then
            # 只清组件不做整包禁用; 数据默认保留(省电策略配置)
            continue
        fi
        is_disabled "$c" || cloud_hard_disable "$c"
        # 已清过就不再清: pm clear 较慢, 重复执行徒增耗时
        [ -f "$CLOUD_FLAG" ] || pm clear "$c" >/dev/null 2>&1 || true
    done
    # 冻结云控联网: 阻止服务端把策略重新推下来
    # (禁用组件后云控仍可能通过其他通道回写, 这个属性可切断)
    resetprop -n persist.sys.sc_allow_conn 0 2>/dev/null || true
    touch "$CLOUD_FLAG" 2>/dev/null || true
    # 关掉之后重刷伪装值并清电池数据, 否则云控遗留值仍在
    cloud_post_action
}

# 恢复云控组件
# 解冻云控联网
#
# 冻结时写的是 persist 属性, 重启也在。只 delete 一次不够:
# 某些环境 resetprop 不可用或部分命令失败, 属性会残留,
# 表现就是"云控恢复了但一直拉不到配置"。这里用多种方式都试一遍。
cloud_unfreeze_conn() {
    resetprop -n persist.sys.sc_allow_conn 1 >/dev/null 2>&1 || true
    resetprop --delete persist.sys.sc_allow_conn >/dev/null 2>&1 || true
    setprop persist.sys.sc_allow_conn 1 >/dev/null 2>&1 || true
    return 0
}

do_cloud_enable() {
    local c left=""
    restore_all_recorded || true
    for c in $CLOUD_COMPONENTS $CLOUD_CLEAR_PKGS; do
        pkg_exists "$c" || continue
        pkg_restore "$c"
    done
    # 恢复云控联网(解冻, 多重方式确保不残留)
    cloud_unfreeze_conn
    rm -f "$CLOUD_FLAG" 2>/dev/null

    # 校验: 仍有包处于禁用就明确报出来, 否则用户不知道到底恢复没有
    for c in $CLOUD_CLEAR_PKGS; do
        pkg_exists "$c" || continue
        is_protected_pkg "$c" && continue
        pkg_still_disabled "$c" && left="$left $(pkg_of "$c")"
    done
    if [ -n "$left" ]; then
        log "云控恢复失败, 以下组件仍为禁用:$left"
        return 1
    fi
    return 0
}

# 强制恢复: 不依赖任何状态标记, 把所有已知目标都恢复一遍
#
# 用于"关了云控之后怎么都恢复不了"的场景 —— 常规路径依赖标志文件,
# 一旦状态混乱(反复刷装/清理过模块目录)就可能漏掉。这里直接全量恢复。
do_cloud_force() {
    local t n=0
    log "强制恢复云控组件…"

    # 1. 按记录清单
    restore_all_recorded || true

    # 2. 全量: 组件 + 包, 一律恢复
    for t in $CLOUD_COMPONENTS $CLOUD_CLEAR_PKGS $LOCK_COMPONENTS $LOCK_PACKAGES; do
        pkg_exists "$t" || continue
        pkg_restore "$t"
        n=$((n + 1))
    done

    # 3. 解冻联网 + 清标志
    cloud_unfreeze_conn
    rm -f "$CLOUD_FLAG" 2>/dev/null

    log "已尝试恢复 $n 个目标"
    log "若仍异常, 可执行 action.sh diag 查看实际状态"
    return 0
}

# BAA 充电配置检测
# 部分机型在 /odm/etc/charger/BAA_config_<代号>.json 中按循环数锁电压,
# 把 cyclecount_index_map 改大即可破解循环锁容(无需伪装循环数)。
# 这里只做检测与提示, 不自动改动系统文件。
baa_scan() {
    local f found=""
    # 路径带 ${SYS_ROOT} 前缀: 真机上为空(即 /odm/...), 测试环境可重定向
    for d in "${SYS_ROOT}/odm/etc/charger" "${SYS_ROOT}/vendor/etc/charger" "${SYS_ROOT}/system/etc/charger"; do
        [ -d "$d" ] || continue
        for f in "$d"/BAA_config*.json; do
            [ -f "$f" ] || continue
            if grep -q "cyclecount_index_map" "$f" 2>/dev/null; then
                found="$found $f"
            fi
        done
    done
    echo "$found" | tr -s ' '
}

# ===== 澎湃特性: BAA 循环锁容破解 =====
#
# 原理(社区实测): /odm/etc/charger/BAA_config_<代号>.json 里的
#   cyclecount_index_map 按循环次数锁定充电电压 —— 循环越高电压压得越低,
#   这是"循环数过高导致锁容"的根源。
#   把该映射改为极大值即可解除, 好处是不必伪装循环数, 仍能查看真实循环。
#   同文件里的阶梯电流参数实测改了也能生效; 温控参数实测不生效(不动)。
#
# 安全设计:
#   - 改前备份原文件, 一次备份永久保留
#   - 改后校验(文件非空 + 仍含关键 key + 大括号平衡), 失败立即还原
#   - 提供 baa restore 一键还原
BAA_BACKUP_DIR="$MODDIR/baa_backup"
BAA_FLAG="$MODDIR/baa_fixed.flag"

# 可写挂载: /odm 等分区常为只读
remount_rw() {
    local p="$1" mp
    mp=$(echo "$p" | sed 's|^\(/[^/]*\).*|\1|')
    [ -f "$p" ] || return 0
    mount -o rw,remount "$mp" 2>/dev/null || true
    # 部分机型需对挂载点本身操作
    for m in /odm /vendor /system; do
        case "$p" in "$m"/*) mount -o rw,remount "$m" 2>/dev/null || true ;; esac
    done
    return 0
}

# JSON 完整性校验: 括号平衡(能挡住绝大多数改坏的情况)
json_ok() {
    local f="$1"
    [ -s "$f" ] || return 1
    grep -q "cyclecount_index_map" "$f" 2>/dev/null || return 1
    local o c
    o=$(tr -cd '{' < "$f" 2>/dev/null | wc -c | tr -d ' ')
    c=$(tr -cd '}' < "$f" 2>/dev/null | wc -c | tr -d ' ')
    [ "${o:-0}" = "${c:-0}" ] || return 1
    o=$(tr -cd '[' < "$f" 2>/dev/null | wc -c | tr -d ' ')
    c=$(tr -cd ']' < "$f" 2>/dev/null | wc -c | tr -d ' ')
    [ "${o:-0}" = "${c:-0}" ] || return 1
    return 0
}

do_baa_fix() {
    local files f bname n=0 ok=0
    files=$(baa_scan)
    if [ -z "$files" ]; then
        log "未找到 BAA 配置文件, 该机型可能不使用此机制"
        return 1
    fi
    mkdir -p "$BAA_BACKUP_DIR" 2>/dev/null

    for f in $files; do
        n=$((n + 1))
        bname=$(echo "$f" | sed 's|/|_|g')
        # 只备份一次: 保留最原始的版本, 否则二次运行会备份已改过的文件
        if [ ! -f "$BAA_BACKUP_DIR/$bname" ]; then
            cp "$f" "$BAA_BACKUP_DIR/$bname" 2>/dev/null || {
                log "  备份失败, 跳过: $f"; continue; }
            # 记录 备份名 -> 原路径 的映射。
            # 不能靠"把 _ 换回 /"反推: 文件名里的下划线也会被替换,
            # 例如 BAA_config_haotian.json 会被还原成 BAA/config/haotian.json,
            # 结果找不到目标文件, 还原静默失败。
            echo "$bname|$f" >> "$BAA_BACKUP_DIR/.map" 2>/dev/null
        fi
        remount_rw "$f"
        # 改前已是修改版则跳过(幂等)
        if grep -q "999999" "$f" 2>/dev/null; then
            log "  已破解过, 跳过: $(basename "$f")"
            ok=$((ok + 1)); continue
        fi
        # 保留数组首个元素(起始档), 其后全部改大 —— 这样永远落在第一档(不锁容)
        # 用 awk 处理, 同时兼容单行与多行格式化的数组
        awk '
          /cyclecount_index_map/ { inmap=1 }
          inmap {
            gsub(/,[ \t]*[0-9]+/, ",999999")
            if (/\]/) inmap=0
          }
          { print }
        ' "$f" > "$f.tmp" 2>/dev/null
        if [ -s "$f.tmp" ] && json_ok "$f.tmp"; then
            cat "$f.tmp" > "$f" 2>/dev/null && rm -f "$f.tmp" 2>/dev/null
            # 二次校验实际落盘内容
            if json_ok "$f"; then
                log "  已破解: $(basename "$f")"
                ok=$((ok + 1))
            else
                cp "$BAA_BACKUP_DIR/$bname" "$f" 2>/dev/null
                log "  校验失败已还原: $(basename "$f")"
            fi
        else
            rm -f "$f.tmp" 2>/dev/null
            log "  改写异常已跳过: $(basename "$f")"
        fi
    done

    if [ "$ok" -gt 0 ]; then
        touch "$BAA_FLAG" 2>/dev/null
        log "BAA 循环锁容已解除 ($ok/$n 个文件)"
        log "提示: 需重启生效; 现已可查看真实循环数(不必伪装)"
        return 0
    fi
    log "未能破解任何 BAA 配置文件(文件可能只读)"
    return 1
}

do_baa_restore() {
    local f bname n=0
    [ -d "$BAA_BACKUP_DIR" ] || { log "无 BAA 备份, 无需还原"; return 0; }
    if [ -f "$BAA_BACKUP_DIR/.map" ]; then
        while IFS='|' read -r bname f; do
            [ -n "$bname" ] && [ -n "$f" ] || continue
            [ -f "$BAA_BACKUP_DIR/$bname" ] || continue
            [ -f "$f" ] || continue
            remount_rw "$f"
            cp "$BAA_BACKUP_DIR/$bname" "$f" 2>/dev/null && {
                log "  已还原: $(basename "$f")"; n=$((n + 1)); }
        done < "$BAA_BACKUP_DIR/.map"
    fi
    rm -f "$BAA_FLAG" 2>/dev/null
    if [ "$n" -gt 0 ]; then
        log "已还原 $n 个 BAA 配置文件, 重启生效"
    else
        log "未找到可还原的目标"
    fi
    return 0
}

# ===== 澎湃特性: PPS/PD 通用快充认证 =====
#
# 小米澎湃秒充基于公有 PPS 魔改。骁龙/联发科各有节点记录 PD 认证状态,
# 置 1 可让老机型也识别通用 PPS 充电器达到高功率(澎湃 P1/P2 芯片机型有效)。
# 只是改一个认证标志位, 不提高硬件上限, 相对安全。
PD_FLAG="$MODDIR/pd_enabled.flag"

pd_nodes() {
    local n
    for n in /sys/class/qcom-battery/pd_verifed \
             /sys/class/qcom-battery/pd_verified \
             /sys/class/Charging_Adapter/pd_adapter/usbpd_verifed \
             /sys/class/Charging_Adapter/pd_adapter/usbpd_verified \
             /sys/class/power_supply/battery/pd_verifed; do
        [ -f "${SYS_ROOT}$n" ] && echo "$n"
    done
    return 0
}

do_pd() {
    local arg="${1:-}" n cnt=0 ok=0 cur
    case "$arg" in
        off|0)
            for n in $(pd_nodes); do
                echo 0 > "${SYS_ROOT}$n" 2>/dev/null && cnt=$((cnt + 1))
            done
            rm -f "$PD_FLAG" 2>/dev/null
            log "已关闭 PPS 认证解锁"
            return 0 ;;
    esac
    local nodes
    nodes=$(pd_nodes)
    if [ -z "$nodes" ]; then
        log "未找到 PD 认证节点, 该机型不支持"
        return 1
    fi
    for n in $nodes; do
        cnt=$((cnt + 1))
        cur=$(cat "${SYS_ROOT}$n" 2>/dev/null | tr -cd '0-9')
        if [ "$cur" = "1" ] || echo 1 > "${SYS_ROOT}$n" 2>/dev/null; then
            ok=$((ok + 1))
        fi
    done
    if [ "$ok" -gt 0 ]; then
        touch "$PD_FLAG" 2>/dev/null
        log "PPS 通用快充认证已解锁 ($ok/$cnt 个节点)"
        log "提示: 需插着充电器操作, 用第三方 PPS 充电器可达更高功率"
        return 0
    fi
    log "认证解锁失败(节点只读或无权限)"
    return 1
}

# ===== 省电: 关掉无谓耗电 =====
#
# 只动明确无用的: 广告服务(msa) 与 WiFi 始终扫描。
# 不涉及可能承载系统功能的组件(如 daemon), 避免"删了模块功能没了"。
PWS_FLAG="$MODDIR/powersave.flag"
MSA_PKGS="com.miui.systemAdSolution com.miui.msa.global"

do_powersave() {
    local arg="${1:-}" p n=0
    case "$arg" in
        off|0)
            for p in $MSA_PKGS; do
                pkg_exists "$p" || continue
                cmd appops reset "$p" >/dev/null 2>&1 || true
                pm unsuspend "$p" >/dev/null 2>&1 || true
                pm enable "$p" >/dev/null 2>&1 || true
            done
            settings put global wifi_scan_always_enabled 1 >/dev/null 2>&1 || true
            rm -f "$PWS_FLAG" 2>/dev/null
            log "已关闭省电优化(恢复广告服务与 WiFi 扫描)"
            return 0 ;;
    esac
    for p in $MSA_PKGS; do
        pkg_exists "$p" || continue
        if try_disable "$p"; then
            log "  已停用广告服务: $p"
            n=$((n + 1))
        fi
    done
    settings put global wifi_scan_always_enabled 0 >/dev/null 2>&1 || true
    log "  已关闭 WiFi 始终扫描"
    touch "$PWS_FLAG" 2>/dev/null
    log "省电优化已开启(停用了 $n 个广告服务)"
    return 0
}
do_baa() {
    local files n
    files=$(baa_scan)
    if [ -z "$files" ]; then
        log "  未检测到 BAA 充电配置文件(该机型可能不使用此机制)"
        return 0
    fi
    n=0
    for f in $files; do n=$((n+1)); done
    log "  检测到 $n 个 BAA 配置(含循环锁容映射):"
    for f in $files; do
        log "    $f"
    done
    log ""
    log "  这类文件按循环次数锁定充电电压, 是循环数过高导致锁容的根源。"
    log "  将其中的 cyclecount_index_map 改为极大值可解除该限制,"
    log "  好处是不必伪装循环数, 仍能查看真实循环。"
    log ""
    log "  执行 action.sh baa fix 自动破解(会备份, 可 baa restore 还原)"
    log "  执行 action.sh baa restore 还原为原始文件"
    return 0
}


# 云控开关: 无参数=切换, on=禁用, off=恢复
do_cloud() {
    case "${1:-}" in
        on|disable)
            do_cloud_disable
            log "云控已禁用 (组件已停用, 云控数据已清空)"
            ;;
        off|enable)
            if do_cloud_enable; then
                log "云控已恢复 (组件已启用)"
            else
                log "云控恢复未完全成功, 可执行 action.sh cloudforce 强制恢复"
            fi
            ;;
        *)
            if [ -f "$CLOUD_FLAG" ]; then
                if do_cloud_enable; then
                    log "云控已恢复 (组件已启用)"
                else
                    log "云控恢复未完全成功, 可执行 action.sh cloudforce 强制恢复"
                fi
            else
                do_cloud_disable
                log "云控已禁用 (组件已停用, 云控数据已清空)"
            fi
            ;;
    esac
    update_prop_desc
}

# 云控策略切换: full / clear / off
do_cloudmode() {
    local m="${1:-}"
    case "$m" in
        full|clear|off)
            set_cloud_mode "$m"
            case "$m" in
                off) do_cloud_enable || log "  恢复未完全成功, 可执行 action.sh cloudforce" ;;
                *)   do_cloud_disable ;;
            esac
            case "$m" in
                full)  log "云控策略: 硬控 (禁用组件 + 清数据)" ;;
                clear) log "云控策略: 软控 (只清数据, 组件保留可用)" ;;
                off)   log "云控策略: 关闭 (不做处理, 仅靠循环伪装)" ;;
            esac
            update_prop_desc
            ;;
        *)
            log "用法: action.sh cloudmode [full|clear|off]"
            log "  full  硬控: 禁用云控组件并清除数据"
            log "  clear 软控: 只清除数据, 保留云控组件可用"
            log "  off   关闭: 不处理云控, 仅用循环伪装"
            log "当前策略: $(cloud_mode)"
            ;;
    esac
}

# 清理字符串里的 JSON 特殊字符
json_str() {
    printf '%s' "${1:-}" | sed 's/["\\]/ /g' | tr -d '\n' | tr -d '\r'
}

# 取包版本号
pkg_version() {
    local v
    v=$(pm dump "$1" 2>/dev/null | grep -m1 "versionName" | sed 's/.*versionName=//; s/[[:space:]]*$//')
    [ -z "$v" ] && v="未安装"
    echo "$v"
}

# 组件版本: joyose / 手机管家 / 电量管理
do_versions() {
    log "  joyose:       $(pkg_version com.xiaomi.joyose)"
    log "  手机管家:     $(pkg_version com.miui.securitycenter)"
    log "  电量管理:     $(pkg_version com.miui.powerkeeper)"
    log "  模块版本:     $(grep '^version=' "$MODULE_PROP" 2>/dev/null | cut -d= -f2)"
}

# 输出充电采样日志(供 WebUI 画曲线)
# 电池 sysfs 路径(action.sh 侧, 与 service.sh 的 find_bat 对应)
find_battery_path() {
    local p
    for p in battery battery0 Battery bms; do
        [ -d "$SYS_ROOT/sys/class/power_supply/$p" ] && {
            echo "$SYS_ROOT/sys/class/power_supply/$p"; return; }
    done
    echo "$SYS_ROOT/sys/class/power_supply/battery"
}

charge_live_mins() {
    local now sT mins
    [ -f "$CHG_STATE" ] || { echo 0; return 0; }
    now=$(date +%s 2>/dev/null); sT=$(cat "$CHG_STATE" 2>/dev/null | tr -cd '0-9')
    [ -z "$sT" ] && { echo 0; return 0; }
    if [ "$now" -gt "$sT" ]; then mins=$(( (now - sT) / 60 )); else mins=0; fi
    echo "$mins"
}
charge_live_from() {
    local v
    if [ -f "$CHG_FROM" ]; then
        v=$(cat "$CHG_FROM" 2>/dev/null | tr -cd '0-9')
        # 文件存在但内容为空/非数字时会得到空串, 拼进 JSON 变成 "chgFrom":,
        # 同样会让整段 JSON 解析失败
        [ -n "$v" ] && { echo "$v"; return 0; }
    fi
    echo 0
}
sess_count() {
    [ -f "$SESSIONS" ] && { wc -l < "$SESSIONS" 2>/dev/null | tr -d ' '; return 0; }
    echo 0
}

# 终端可读的充电统计汇总
do_chargestat() {
    local design tot line cnt sum_min sum_gain last_m last_g
    design=$(cat "$(find_battery_path)/charge_full_design" 2>/dev/null | tr -cd '0-9')
    [ -z "$design" ] && design=$(getprop ro.battery.capacity 2>/dev/null | tr -cd '0-9')
    [ -z "$design" ] && design=5000
    design=$((design / 1000))
    [ "$design" -le 0 ] && design=5000

    if [ ! -f "$SESSIONS" ] && [ ! -f "$CHG_STATE" ]; then
        log "暂无充电记录"
        log "提示: 确认已开启(action.sh chargelog on)且守护进程在运行"
        return 0
    fi

    cnt=0; sum_min=0; sum_gain=0; sum_p=0; np=0
    if [ -f "$SESSIONS" ]; then
        while read -r line; do
            [ -z "$line" ] && continue
            cnt=$((cnt + 1))
            m=$(echo "$line" | grep -oE '"mins":[0-9]+' | cut -d: -f2)
            g=$(echo "$line" | grep -oE '"to":[0-9]+' | cut -d: -f2)
            f=$(echo "$line" | grep -oE '"from":[0-9]+' | cut -d: -f2)
            [ -z "$m" ] && m=0
            [ -z "$g" ] && g=0
            [ -z "$f" ] && f=0
            sum_min=$((sum_min + m))
            if [ "$g" -ge "$f" ]; then sum_gain=$((sum_gain + g - f)); fi
            ap=$(echo "$line" | grep -oE '"avgP":[0-9]+' | cut -d: -f2)
            if [ -n "$ap" ] && [ "$ap" -gt 0 ]; then
                sum_p=$((sum_p + ap)); np=$((np + 1))
            fi
        done < "$SESSIONS"
    fi

    log "===== 充电统计 ====="
    log "已完成充电: $cnt 次"
    if [ "$cnt" -gt 0 ]; then
        log "累计时长:   $sum_min 分钟"
        log "累计充入:   $sum_gain % (约 $((sum_gain * design / 100)) mAh)"
        log "平均单次:   $((sum_min / cnt)) 分钟 / $((sum_gain / cnt)) %"
        if [ "$np" -gt 0 ]; then
            ap=$((sum_p / np))
            log "平均功率:   $(awk -v x="$ap" 'BEGIN{printf "%.1f", x/1000}') W"
        fi
        log ""
        log "最近 5 次:"
        tail -n 5 "$SESSIONS" 2>/dev/null | while read -r l; do
            sm=$(echo "$l" | grep -oE '"mins":[0-9]+' | cut -d: -f2)
            sf=$(echo "$l" | grep -oE '"from":[0-9]+' | cut -d: -f2)
            st=$(echo "$l" | grep -oE '"to":[0-9]+' | cut -d: -f2)
            ss=$(echo "$l" | grep -oE '"s":[0-9]+' | cut -d: -f2)
            [ -z "$sm" ] && sm=0
            [ -z "$sf" ] && sf=0
            [ -z "$st" ] && st=0
            sg=0; [ "$st" -ge "$sf" ] && sg=$((st - sf))
            sap=$(echo "$l" | grep -oE '"avgP":[0-9]+' | cut -d: -f2)
            spp=$(echo "$l" | grep -oE '"peakP":[0-9]+' | cut -d: -f2)
            ssp=$(echo "$l" | grep -oE '"speed":[0-9]+' | cut -d: -f2)
            [ -z "$sap" ] && sap=0
            [ -z "$spp" ] && spp=0
            [ -z "$ssp" ] && ssp=0
            avgw=$(awk -v x="$sap" 'BEGIN{printf "%.1f", x/1000}')
            pkw=$(awk -v x="$spp" 'BEGIN{printf "%.1f", x/1000}')
            spd=$(awk -v x="$ssp" 'BEGIN{printf "%.1f", x/10}')
            log "  $(date -d "@$ss" '+%m-%d %H:%M' 2>/dev/null || echo "$ss")  ${sm}分钟  ${sf}%→${st}%  (+${sg}%)  均${avgw}W 峰${pkw}W ${spd}%/分"
        done
    fi

    if [ -f "$CHG_STATE" ]; then
        local now sT a b mins
        now=$(date +%s 2>/dev/null)
        sT=$(cat "$CHG_STATE" 2>/dev/null | tr -cd '0-9')
        a=$(cat "$CHG_FROM" 2>/dev/null | tr -cd '0-9')
        b=$(cat "$CHG_LAST" 2>/dev/null | tr -cd '0-9')
        [ -z "$sT" ] && sT=0
        [ -z "$a" ] && a=0
        [ -z "$b" ] && b="$a"
        if [ "$now" -gt "$sT" ]; then mins=$(( (now - sT) / 60 )); else mins=0; fi
        log ""
        log "当前正在充电: 已 ${mins} 分钟, ${a}% → ${b}%"
    fi
    return 0
}

# 当前充电会话的实时状态(供 WebUI 顶部显示)
charge_now_state() {
    local st sT lvT now mins a b
    st=$(cat "$(find_battery_path)/status" 2>/dev/null | tr -d ' \r' | tr 'A-Z' 'a-z')
    # 同 service.sh: 必须先排除 discharging / not charging, 否则子串误判
    case "$st" in
        *discharging*) echo 0 ;;
        *not*charging*) echo 0 ;;
        full|*full*) echo 0 ;;
        *charging*) echo 1 ;;
        *) echo 0 ;;
    esac
}

# 会话统计: 输出会话文件 + 当前进行中的会话
do_chargelog() {
    [ -f "$CHARGE_LOG" ] && cat "$CHARGE_LOG" 2>/dev/null || true
}

# 充电记录诊断: 定位"记录不生效"的原因
do_chargelog_diag() {
    local bat st cnt
    log "===== 充电记录诊断 ====="
    if [ ! -f "$CHARGE_LOG_FLAG" ]; then
        log "  采样开关: 未开启"
        log "  执行 action.sh log on 开启"
    else
        log "  采样开关: 已开启"
    fi
    log "  日志文件: $CHARGE_LOG"
    if [ -f "$SESSIONS" ]; then
        sc=$(wc -l < "$SESSIONS" 2>/dev/null | tr -d ' ')
        log "  已完成会话: ${sc:-0} 次"
    else
        log "  已完成会话: 0 次"
    fi
    if [ -f "$CHG_STATE" ]; then
        log "  当前: 正在充电(会话进行中)"
    else
        log "  当前: 未在充电会话中"
    fi
    if [ -f "$CHARGE_LOG" ]; then
        cnt=$(wc -l < "$CHARGE_LOG" 2>/dev/null | tr -d ' ')
        log "  已有记录: ${cnt:-0} 条"
        log "  最近 3 条:"
        tail -n 3 "$CHARGE_LOG" 2>/dev/null | while read -r l; do log "    $l"; done
    else
        log "  已有记录: 0 条(文件不存在)"
    fi
    bat=$(find_battery_path)
    st=$(cat "$bat/status" 2>/dev/null)
    log "  当前充电状态: ${st:-读不到}"
    [ "$st" != "Charging" ] && log "  提示: 仅在充电时采样, 现在未在充电"
    if ! service_running; then
        log "  守护进程: 未运行 —— 采样由守护完成, 未运行则不会记录"
        log "  执行 action.sh unlock 或重启以拉起守护"
    else
        log "  守护进程: 运行中"
    fi
    return 0
}

# 开关充电记录采样
do_chargelog_switch() {
    case "${1:-}" in
        on|1|enable)
            touch "$CHARGE_LOG_FLAG" 2>/dev/null || true
            ensure_daemon
            log "充电记录已开启(需守护进程运行中, 每 60 秒采样一次)"
            ;;
        off|0|disable)
            rm -f "$CHARGE_LOG_FLAG" 2>/dev/null || true
            log "充电记录已关闭"
            ;;
        *)
            [ -f "$CHARGE_LOG_FLAG" ] && log "充电记录: 已开启" || log "充电记录: 已关闭"
            ;;
    esac
    return 0
}

# 清除充电记录
do_clearlog() {
    rm -f "$CHARGE_LOG" "$SESSIONS" 2>/dev/null || true
    rm -f "$CHG_STATE" "$CHG_FROM" "$CHG_LAST" "$CHG_LASTT" "$CHG_N" \
          "$CHG_SUMP" "$CHG_MAXP" "$CHG_NP" 2>/dev/null || true
    log "充电记录与统计已清除"
}

# 强力修复: 彻底恢复所有被本模块动过的组件
#
# 群友反馈"关闭云控后再也恢复不了"。普通恢复失败时用它。
# 比常规恢复多做几件事:
#   1. 清 appops 到默认(逐个 set 到 allow 之外, 再 reset 一次)
#   2. 对所有用户 enable / unsuspend
#   3. 解除可能残留的挂起与休眠限制(standby bucket)
#   4. 还原云控联网属性
#   5. 逐个校验, 失败的列出来
do_fixcloud() {
    local p n=0 left="" seen=""

    # 恢复对象: 清单记录的 + 已知可能被动过的
    local targets=""
    [ -f "$DISABLED_LIST" ] && targets="$targets $(cat "$DISABLED_LIST" 2>/dev/null)"
    targets="$targets $LOCK_COMPONENTS $LOCK_PACKAGES $CLOUD_COMPONENTS $CLOUD_CLEAR_PKGS"

    for t in $targets; do
        p=$(pkg_of "$t")
        [ -z "$p" ] && continue
        # 去重
        case " $seen " in *" $p "*) continue ;; esac
        seen="$seen $p"
        pkg_exists "$p" || continue

        # 1. appops: reset 之后再显式 allow 一遍(部分 rom reset 不彻底)
        cmd appops reset "$p" >/dev/null 2>&1 || true
        for op in RUN_IN_BACKGROUND RUN_ANY_IN_BACKGROUND \
                  BOOT_COMPLETED WAKE_LOCK; do
            cmd appops set "$p" "$op" allow >/dev/null 2>&1 || true
        done
        # 2. 解除挂起 / 待机分组限制
        pm unsuspend "$p" >/dev/null 2>&1 || true
        cmd am set-standby-bucket "$p" active >/dev/null 2>&1 || true
        # 3. 对所有用户 enable(维护模式 + 逐用户)
        settings put global maintenance_mode_user_id 110 >/dev/null 2>&1 || true
        for u in $(active_users); do
            pm enable --user "$u" "$p" >/dev/null 2>&1 || true
            pm enable --user "$u" "$t" >/dev/null 2>&1 || true
        done
        settings delete global maintenance_mode_user_id >/dev/null 2>&1 || true
        pm enable "$t" >/dev/null 2>&1 || true
        pm enable "$p" >/dev/null 2>&1 || true

        n=$((n + 1))
        pkg_still_disabled "$p" && left="$left $p"
    done

    # 4. 还原云控联网与充电上限
    resetprop -n persist.sys.sc_allow_conn 1 2>/dev/null || true
    resetprop --delete persist.sys.sc_allow_conn 2>/dev/null || true
    for prop in persist.sys.charging_stop_level \
                persist.sys.battery.charging_stop \
                persist.vendor.battery.charging_stop_level \
                persist.sys.bms.charging_stop_level; do
        resetprop -n "$prop" 80 2>/dev/null || true
    done
    settings delete global charging_stop_level >/dev/null 2>&1 || true

    # 5. 清状态标记
    rm -f "$CLOUD_FLAG" "$PERSIST_FLAG" 2>/dev/null
    set_cloud_mode off 2>/dev/null || true
    rm -f "$DISABLED_LIST" 2>/dev/null

    if [ -n "$left" ]; then
        log "已处理 $n 个组件, 但以下仍为禁用状态:$left"
        log "请在 设置 → 应用设置 → 应用管理 中手动启用"
        return 1
    fi
    log "已彻底恢复 $n 个组件"
    return 0
}

# 帮助: 列出所有命令。用户不知道有哪些命令时最有用到。
do_help() {
    log "===== 解除锁容 命令一览 ====="
    log ""
    log "[核心]"
    log "  unlock              解除充电限制(80% 上限、清学习数据)"
    log "  lock                恢复充电限制"
    log "  restore             恢复默认(还原真实循环、恢复云控)"
    log "  status              查看当前状态面板"
    log ""
    log "[循环伪装]"
    log "  fake <次数>         伪装循环数, 如 fake 5"
    log "  fake off            关闭伪装并还原真实值"
    log ""
    log "[云控]"
    log "  cloudmode full      硬控: 停组件 + 清数据"
    log "  cloudmode clear     软控: 只清数据, 组件保留"
    log "  cloudmode off       关闭"
    log "  fixcloud            强力恢复云控组件(解冻失败时用)"
    log ""
    log "[澎湃特性]"
    log "  baa                 检测 BAA 循环锁容配置"
    log "  baa fix             破解(自动备份, 可还原)"
    log "  baa restore         还原配置"
    log "  pd on|off           PPS 通用快充认证"
    log "  powersave on|off    停用广告服务、关 WiFi 常扫"
    log ""
    log "[充电统计]"
    log "  chargelog on|off    开关充电记录"
    log "  chargelog diag      记录不生效时排查"
    log "  chargestat          查看统计(时长/功率/速度)"
    log "  clearlog            清除记录"
    log ""
    log "[其他]"
    log "  cap [mAh]           容量解锁(不带参数按设计值)"
    log "  volt on|off         充电截止电压解锁(默认关, 有风险)"
    log "  sdv                 查看关机电压各节点当前值"
    log "  sdv safe|normal|aggressive|extreme"
    log "                      关机电压预设档(3400/3300/3200/2500)"
    log "  sdv <数值> --force  自定义关机电压, 须显式确认"
    log "  sdv off             还原关机电压"
    log "  bov ...             开机电压(用法同 sdv)"
    log "  selinux [enforce]   查看/切换 SELinux"
    log "  diag                全面诊断"
    log "  scan                全机扫描(解容没生效时用它定位)"
    log "  versions            组件版本"
    log "  setup               键盘交互配置(音量键失灵时用)"
    log "  keytest             检测音量键是否可用"
    log "  author              作者信息"
    log ""
    log "模块目录: $MODDIR"
    return 0
}

# ===== 关机电压 / 开机电压 =====
#
# 风险最高的两项, 因此操作前一律打印风险提示, 且自定义值必须显式 --force。

RISK_LINE="本操作会改写内核电池参数。设置不当可能造成电池过放、鼓包、容量永久衰减, 甚至无法充电。出现问题由使用者自行承担全部责任。"

warn_risk() {
    log ""
    log "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    log "  高风险操作"
    log "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    log "  $RISK_LINE"
    log "  建议先记录当前值, 出现问题可执行还原命令。"
    log "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
    log ""
}

# 按节点原单位写入 mV: 原值 >=6 位视为 uV, 否则视为 mV
# 读节点原始字符串(保留 0x 前缀, 不去字符)
#
# 之前用 tr -cd '0-9' 会把 "0x9c4" 清成 "094" —— 值直接被破坏,
# 而且写回后比对也永远对不上, 表现就是"改了但没生效"。
node_raw() {
    cat "$1" 2>/dev/null | tr -d ' \t\r\n'
}

# hex 字符串转十进制 (0x9c4 -> 2500)
# 不用 printf '%d' 0x...: 各 shell 实现不一致, 有的直接报错
hex2dec() {
    local h i c d=0 n
    h=$(echo "${1#0x}" | tr 'A-F' 'a-f')
    [ -z "$h" ] && { echo 0; return 0; }
    n=${#h}
    i=1
    while [ "$i" -le "$n" ]; do
        c=$(echo "$h" | cut -c"$i")
        case "$c" in
            [0-9]) ;;
            a) c=10 ;; b) c=11 ;; c) c=12 ;;
            d) c=13 ;; e) c=14 ;; f) c=15 ;;
            *) i=$((i + 1)); continue ;;
        esac
        d=$((d * 16 + c))
        i=$((i + 1))
    done
    echo "$d"
}

# 把节点原始值解析成十进制"裸值"(不做单位换算)
node_dec() {
    local raw
    raw=$(node_raw "$1")
    [ -z "$raw" ] && { echo ""; return 1; }
    case "$raw" in
        0x*|0X*) hex2dec "$raw" ;;
        *)       echo "$raw" | tr -cd '0-9' ;;
    esac
}

# 原始值是否 hex 形式
is_hex_node() {
    case "$(node_raw "$1")" in 0x*|0X*) return 0 ;; *) return 1 ;; esac
}

# 解析成 mV: hex 先转十进制, 再按数量级判单位(>=100000 视为 uV)
read_one_mv() {
    local v
    v=$(node_dec "$1")
    [ -z "$v" ] && return 1
    [ "$v" -eq 0 ] 2>/dev/null && return 1
    if [ "$v" -ge 100000 ] 2>/dev/null; then
        echo $((v / 1000))
    else
        echo "$v"
    fi
}

# 写 mV 到节点: 自动匹配节点原本的格式与单位
#
# - 原值是 hex(如 0x9c4) -> 写 hex 形式 0x9c4
# - 原值 >= 100000      -> 视为 uV, 写 mv*1000
# - 否则                -> 视为 mV, 直接写 mv
#
# 写完全按"回读字符串一致"来判定成功, 不做数值近似, 避免把
# 写歪了的值误判为成功。
write_mv() {
    local node="$1" mv="$2" target got
    if is_hex_node "$node"; then
        target=$(printf '0x%x' "$mv" 2>/dev/null)
        [ -z "$target" ] && return 1
    else
        local rawv
        rawv=$(node_dec "$node")
        if [ -n "$rawv" ] && [ "$rawv" -ge 100000 ] 2>/dev/null; then
            target=$((mv * 1000))
        else
            target="$mv"
        fi
    fi
    backup_node "$node"
    chmod 644 "$node" 2>/dev/null || true
    echo "$target" > "$node" 2>/dev/null || return 1
    got=$(node_raw "$node")
    [ "$got" = "$target" ] && return 0
    return 1
}

read_mv() {
    local n v
    for n in $(list_existing "$1"); do
        v=$(read_one_mv "$n") && { echo "$v"; return 0; }
    done
}

# 通用实现: $1=节点列表 $2=flag文件 $3=值文件 $4=下限 $5=上限 $6=名称 $7=参数
do_volt_thresh() {
    local nodes="$1" flag="$2" vfile="$3" vmin="$4" vmax="$5" vname="$6"
    local cmd="${7:-}" arg="${8:-}" sub="${9:-}"
    local preset target ok=0 cnt=0 n

    nodes=$(list_existing "$nodes")
    if [ -z "$nodes" ]; then
        log "该机型未暴露${vname}节点, 不支持修改"
        log "此项多为电池固件固化的参数, 多数机型无法更改"
        return 1
    fi

    case "$arg" in
        off|restore)
            # 逐节点还原, 不能用统一的一个值
            #
            # 各层原值本来就不同(如 voltage_min=3400 而 vcutoff=3300),
            # 若拿"第一个节点的值"去写所有节点, 会把各层原本的差异抹掉 ——
            # 表现为"还原了但值不对"(实测 0xce4 被写成 0xd48)。
            # 备份目录里存的是每个节点各自的原值, 按节点逐个还原。
            for n in $nodes; do restore_node "$n"; done
            rm -f "$flag" "$vfile" "$vfile.orig" 2>/dev/null
            log "${vname}已还原为原始值"
            return 0 ;;
        status|"")
            cur=$(read_mv "$1")
            log "===== ${vname} ====="
            log "  当前值: ${cur:-未知} mV"
            log "  可调范围: ${vmin} ~ ${vmax} mV"
            log "  预设: safe / normal / aggressive / extreme"
            log "  用法: action.sh $cmd safe | $cmd <数值> --force | $cmd off"
            log ""
            # 逐节点列出: sw 与 fw 是两层, 只改一层等于没改,
            # 必须让用户能看到每一层各自是多少
            log "  各节点当前值:"
            for n in $nodes; do
                raw=$(node_raw "$n")
                mv=$(read_one_mv "$n")
                # subpmic 要先判: 它的节点名也含 vcutoff_sw/fw,
                # 顺序反了会被标成"(软件)"而不是"(子PMIC)"
                case "$n" in
                    *subpmic*)    tag="(子PMIC)" ;;
                    *vcutoff_sw*) tag="(软件)" ;;
                    *vcutoff_fw*) tag="(固件)" ;;
                    *)            tag="" ;;
                esac
                log "    ${n#$SYS_ROOT} = ${raw}${mv:+ ≈${mv}mV} $tag"
            done
            return 0 ;;
        safe)        preset=3400 ;;
        normal)      preset=3300 ;;
        aggressive)  preset=3200 ;;
        # 极限档: 2.5V。电芯放电终止电压, 能榨出最多电量,
        # 但同时改 vcutoff_sw / vcutoff_fw / subpmic 三层。
        extreme)     preset=2500 ;;
        *)
            # 自定义数值
            echo "$arg" | grep -qE '^[0-9]+$' || {
                log "无效参数: $arg"; log "用法: $6 safe|normal|aggressive|<数值> --force|off"; return 1; }
            if [ "$sub" != "--force" ] && [ "$sub" != "-f" ]; then
                log "自定义${vname}需要显式确认。"
                warn_risk
                log "确认请执行: action.sh $cmd $arg --force"
                log "或改用预设档: safe(3400) / normal(3300) / aggressive(3200) / extreme(2500)"
                return 1
            fi
            preset="$arg" ;;
    esac

    # 硬边界检查: 不接受绕过
    if [ "$preset" -lt "$vmin" ] || [ "$preset" -gt "$vmax" ]; then
        log "拒绝: 目标 ${preset} mV 超出安全边界 ${vmin}~${vmax} mV。"
        log "此边界不可绕过 —— 超出会造成不可逆的电池损伤。"
        return 1
    fi

    warn_risk
    for n in $nodes; do
        cnt=$((cnt + 1))
        write_mv "$n" "$preset" && ok=$((ok + 1))
    done
    if [ "$ok" -gt 0 ]; then
        echo "$preset" > "$vfile" 2>/dev/null
        touch "$flag" 2>/dev/null
        log "${vname}已设为 ${preset} mV ($ok/$cnt 个节点)"
        log "还原: action.sh $cmd off"
        return 0
    fi
    log "${vname}设置失败: 节点只读或无权限"
    return 1
}

do_sdv() {
    do_volt_thresh "$SHUTDOWN_V_NODES" "$MODDIR/sdv_enabled.flag" \
                   "$MODDIR/sdv_value" "$SHUTDOWN_V_MIN" "$SHUTDOWN_V_MAX" \
                   "关机电压" "sdv" "${1:-}" "${2:-}"
}
do_bov() {
    do_volt_thresh "$BOOT_V_NODES" "$MODDIR/bov_enabled.flag" \
                   "$MODDIR/bov_value" "$BOOT_V_MIN" "$BOOT_V_MAX" \
                   "开机电压" "bov" "${1:-}" "${2:-}"
}

# ===== 全机扫描诊断 =====
#
# 目的: 大量机型"解容没生效", 根因往往是本模块没覆盖到该机型的
#   包名/节点名。这个命令把本机所有相关的包名与节点都列出来,
#   用户把输出发过来即可定位缺什么, 而不是靠猜。

# 扫描 power_supply / qcom-battery / xm_power / bms 下含关键词的节点
scan_nodes() {
    local kw="$1" base d f
    for base in "${SYS_ROOT}/sys/class/power_supply" \
                "${SYS_ROOT}/sys/class/qcom-battery" \
                "${SYS_ROOT}/sys/class/xm_power" \
                "${SYS_ROOT}/sys/class/bms" \
                "${SYS_ROOT}/sys/class/Charging_Adapter"; do
        [ -d "$base" ] || continue
        for d in "$base" "$base"/*/; do
            [ -d "$d" ] || continue
            for f in "$d"*; do
                [ -f "$f" ] || continue
                case "$(basename "$f")" in
                    *$kw*) echo "$f" ;;
                esac
            done
        done
    done
    return 0
}

do_scan() {
    local n cur w

    log "===== 全机扫描诊断 ====="
    log "机型: $(device_name) ($(getprop ro.product.device))"
    log "内核: $(uname -r)"
    log ""

    log "[循环次数节点]"
    for n in $(scan_nodes "cycle"); do
        cur=$(cat "$n" 2>/dev/null | tr -cd '0-9')
        # 试探可写性: 读原值 → 写回原值 → 判断是否真的可写
        w="只读"
        if [ -n "$cur" ]; then
            chmod 644 "$n" 2>/dev/null
            echo "$cur" > "$n" 2>/dev/null && w="可写"
        fi
        log "  ${n#$SYS_ROOT} = ${cur:-?} ($w)"
    done
    log ""

    log "[容量节点]"
    for n in $(scan_nodes "charge_full"); do
        cur=$(cat "$n" 2>/dev/null | tr -cd '0-9')
        w="只读"
        if [ -n "$cur" ]; then
            chmod 644 "$n" 2>/dev/null
            echo "$cur" > "$n" 2>/dev/null && w="可写"
        fi
        log "  ${n#$SYS_ROOT} = ${cur:-?} ($w)"
    done
    log ""

    log "[电压节点]"
    for n in $(scan_nodes "voltage"); do
        cur=$(cat "$n" 2>/dev/null | tr -cd '0-9')
        log "  ${n#$SYS_ROOT} = ${cur:-?}"
    done
    log ""

    log "[电池/电源相关包]"
    if command -v pm >/dev/null 2>&1; then
        pm list packages 2>/dev/null | sed 's/^package://' | grep -iE \
            'battery|power|charge|thermal|joyose|analytic|daemon|cloud|miui.security' \
            | while read -r p; do
                st="启用"
                is_disabled "$p" && st="禁用"
                is_protected_pkg "$p" && st="$st(受保护)"
                log "  $p [$st]"
            done
    fi
    log ""

    log "[BAA 配置]"
    local b f
    b=$(baa_scan)
    if [ -z "$b" ]; then
        log "  无"
    else
        for f in $b; do log "  $f"; done
    fi

    log ""
    log "把以上输出发给作者, 可据此补充该机型的适配。"
    return 0
}

# WebUI 数据接口: 输出单行 JSON
# 手动清除受保护包(powerkeeper)数据
#
# 默认不自动清, 因为 pm clear 会连省电策略配置一起清掉。
# 若需要更彻底地清除已下发的云控配置, 可手动执行此命令,
# 代价是省电策略需要重新设置。
do_clearpk() {
    local c n=0
    # 清 joyose 数据会丢用户设置(游戏工具箱 / 充电提示音),
    # 且删除不可逆 —— 所以只在显式执行这条命令时才做, 并明确警告。
    for c in $CLOUD_CLEAR_MANUAL; do
        pkg_exists "$c" || continue
        pm clear "$c" >/dev/null 2>&1 && n=$((n + 1))
    done
    if [ "$n" -gt 0 ]; then
        log "已清除 $n 个包的云控数据"
        log "警告: joyose 的用户设置(游戏工具箱、充电提示音等)已一并清空,"
        log "      这是不可逆的, 需要在系统设置里重新配置。"
    else
        log "未找到 joyose 或清除失败"
    fi
    return 0
}

pd_count() {
    local n c=0
    for n in $(pd_nodes); do c=$((c + 1)); done
    echo "$c"
}
sdv_sup() {
    local n c=0
    for n in $(list_existing "$SHUTDOWN_V_NODES"); do c=$((c + 1)); done
    echo "$c"
}
bov_sup() {
    local n c=0
    for n in $(list_existing "$BOOT_V_NODES"); do c=$((c + 1)); done
    echo "$c"
}

# 输出充电会话数据供 WebUI 统计展示
#
# 格式: 先输出一行当前会话(正在充电时), 再逐行输出历史会话。
# 前端据此画"本次充电"与历史列表。
do_sessions() {
    local now sT a b mins sump np avgP mxp
    # 正在充电: 输出实时会话(含当前平均功率)
    if [ -f "$CHG_STATE" ]; then
        now=$(date +%s 2>/dev/null); [ -z "$now" ] && now=0
        sT=$(cat "$CHG_STATE" 2>/dev/null | tr -cd '0-9')
        a=$(cat "$CHG_FROM" 2>/dev/null | tr -cd '0-9')
        b=$(cat "$CHG_LAST" 2>/dev/null | tr -cd '0-9')
        sump=$(cat "$CHG_SUMP" 2>/dev/null | tr -cd '0-9')
        np=$(cat "$CHG_NP" 2>/dev/null | tr -cd '0-9')
        mxp=$(cat "$CHG_MAXP" 2>/dev/null | tr -cd '0-9')
        [ -z "$sT" ] && sT="$now"
        [ -z "$a" ] && a=0
        [ -z "$b" ] && b="$a"
        [ -z "$sump" ] && sump=0
        [ -z "$np" ] && np=0
        [ -z "$mxp" ] && mxp=0
        if [ "$now" -gt "$sT" ]; then mins=$(( (now - sT) / 60 )); else mins=0; fi
        avgP=0; [ "$np" -gt 0 ] && avgP=$((sump / np))
        printf '{"live":1,"s":%s,"e":%s,"from":%s,"to":%s,"mins":%s,"avgP":%s,"peakP":%s}\n' \
            "$sT" "$now" "$a" "$b" "$mins" "$avgP" "$mxp"
    fi
    [ -f "$SESSIONS" ] && tail -n 30 "$SESSIONS" 2>/dev/null
    return 0
}

do_api() {
    collect_info
    local cur vol pwr=0 lv=0
    cur=$(cat "$BAT/current_now" 2>/dev/null | tr -cd '0-9')
    vol=$(cat "$BAT/voltage_now" 2>/dev/null | tr -cd '0-9')
    if [ -n "$cur" ] && [ -n "$vol" ]; then
        pwr=$(awk -v c="$cur" -v v="$vol" 'BEGIN{printf "%.1f", (c/1000000)*(v/1000000)}')
    fi
    [ -z "$pwr" ] && pwr=0
    # level 必须兜底: 节点缺失时 tr 得到空串, 拼进 JSON 会变成 "level":, 造成非法
    lv=$(printf '%s' "${CAP:-0}" | tr -cd '0-9')
    [ -z "$lv" ] && lv=0

    local u=0 f=0 cl=0 cp=0 vu=0 dm=0
    [ -f "$PERSIST_FLAG" ] && u=1
    [ -f "$FAKE_FLAG" ]   && f=1
    [ -f "$CLOUD_FLAG" ]  && cl=1
    [ -f "$CAP_FLAG" ]    && cp=1
    [ -f "$VOLT_FLAG" ]   && vu=1
    service_running && dm=1

    local fv rc cv bn=0 cd=0 sdvv=0 bovv=0
    fv=$(cat "$MODDIR/fake_value" 2>/dev/null | tr -cd '0-9');    [ -z "$fv" ] && fv=0
    rc=$(cat "$REAL_CYCLE_FILE" 2>/dev/null | tr -cd '0-9');      [ -z "$rc" ] && rc=0
    cv=$(cat "$CAP_FILE" 2>/dev/null | tr -cd '0-9');             [ -z "$cv" ] && cv=0
    # 电压值必须兜底: 文件不存在时为空串, 拼进 JSON 会变成 "sdvVal":,
    # 整段 JSON 解析失败 —— WebUI 就会显示"读取失败"(v3.0.1 的实际故障)
    sdvv=$(cat "$MODDIR/sdv_value" 2>/dev/null | tr -cd '0-9');   [ -z "$sdvv" ] && sdvv=0
    bovv=$(cat "$MODDIR/bov_value" 2>/dev/null | tr -cd '0-9');   [ -z "$bovv" ] && bovv=0

    # 云控组件的实际禁用状态(与开关意图可能不一致, 用于发现"解冻失败")
    pkg_still_disabled "com.xiaomi.joyose" && cd=1
    # BAA 循环锁容配置文件数量
    for _f in $(baa_scan); do bn=$((bn + 1)); done

    printf '{"device":"%s","level":%s,"status":"%s","temp":"%s","volt":"%s","design":%s,"full":%s,"health":"%s","cycle":%s,"cycleStr":"%s","power":%s,"unlock":%s,"fake":%s,"fakeVal":%s,"realCycle":%s,"cloud":%s,"cloudMode":"%s","cap":%s,"capVal":%s,"voltUnlock":%s,"daemon":%s,"selinux":"%s","joyose":"%s","securitycenter":"%s","powerkeeper":"%s","moduleVer":"%s","baa":%s,"cloudDisabled":%s,"root":"%s","logOn":%s,"chgNow":%s,"chgMins":%s,"chgFrom":%s,"sessCount":%s,"baaFixed":%s,"pd":%s,"pdNodes":%s,"pws":%s,"sdv":%s,"sdvVal":%s,"bov":%s,"bovVal":%s,"sdvSup":%s,"bovSup":%s}\n' \
        "$(json_str "$(device_name)")" \
        "$lv" \
        "$(json_str "$SCN")" \
        "$(json_str "$TEMP")" \
        "$(json_str "$VOLT")" \
        "${DESIGN:-0}" "${CURRENT:-0}" \
        "$(json_str "$HEALTH")" \
        "${CYCLE:-0}" "$(json_str "$CYCLE_STR")" \
        "$pwr" \
        "$u" "$f" "$fv" "$rc" "$cl" "$(cloud_mode)" "$cp" "$cv" "$vu" "$dm" \
        "$(json_str "$(selinux_state)")" \
        "$(json_str "$(pkg_version com.xiaomi.joyose)")" \
        "$(json_str "$(pkg_version com.miui.securitycenter)")" \
        "$(json_str "$(pkg_version com.miui.powerkeeper)")" \
        "$(json_str "$(grep '^version=' "$MODULE_PROP" 2>/dev/null | cut -d= -f2)")" \
        "$bn" "$cd" "$(json_str "$(root_flavor)")" \
        "$([ -f "$CHARGE_LOG_FLAG" ] && echo 1 || echo 0)" \
        "$(charge_now_state)" "$(charge_live_mins)" "$(charge_live_from)" \
        "$(sess_count)" \
        "$([ -f "$BAA_FLAG" ] && echo 1 || echo 0)" \
        "$([ -f "$PD_FLAG" ] && echo 1 || echo 0)" "$(pd_count)" \
        "$([ -f "$PWS_FLAG" ] && echo 1 || echo 0)" \
        "$([ -f "$MODDIR/sdv_enabled.flag" ] && echo 1 || echo 0)" \
        "$sdvv" \
        "$([ -f "$MODDIR/bov_enabled.flag" ] && echo 1 || echo 0)" \
        "$bovv" \
        "$(sdv_sup)" "$(bov_sup)"
}

# 循环次数伪装: 写入指定值
# 关闭伪装: 还原真实循环值, 不影响其他开关
do_fake_off() {
    local real
    real=$(cat "$REAL_CYCLE_FILE" 2>/dev/null | tr -cd '0-9')
    if [ -n "$real" ]; then
        write_all_cycle_nodes "$real" >/dev/null 2>&1 || true
        log "循环次数已还原为真实值: ${real}"
    fi
    rm -f "$FAKE_FLAG" "$MODDIR/fake_value" 2>/dev/null
    log "循环伪装已关闭"
    update_prop_desc
}

# 仅恢复系统电量管理, 不动伪装 / 容量 / 电压
do_lock() {
    local t left=""
    restore_all_recorded || true
    for t in $LOCK_COMPONENTS $LOCK_PACKAGES; do
        pkg_exists "$t" || continue
        pkg_restore "$t"
    done
    for t in $LOCK_PACKAGES; do
        pkg_exists "$t" || continue
        pkg_still_disabled "$t" && left="$left $(pkg_of "$t")"
    done
    [ -n "$left" ] && log "警告: 以下组件仍为禁用状态, 可在应用设置中手动启用:$left"
    for prop in persist.sys.charging_stop_level \
                persist.sys.battery.charging_stop \
                persist.vendor.battery.charging_stop_level \
                persist.sys.bms.charging_stop_level; do
        resetprop -n "$prop" 80 2>/dev/null || true
    done
    settings delete global charging_stop_level >/dev/null 2>&1 || true
    rm -f "$PERSIST_FLAG" 2>/dev/null
    log "已恢复系统默认电量管理"
    update_prop_desc
}

do_fake() {
    local val="${1:-20}"
    # 关闭伪装: 只关伪装并还原真实循环值, 不影响解除限制
    [ "$val" = "off" ] && { do_fake_off; return $?; }
    case "$val" in
        *[!0-9]*) log "错误: 循环次数必须是数字, 例如: action.sh fake 5"; return 1 ;;
    esac
    [ "$val" -lt 1 ] && val=1

    # 首次伪装前备份真实循环数, 便于 restore 时还原
    # 注意: 跳过 fake_cycle 这类影子节点(它本身就是伪装通道, 读到的是伪装值),
    #       只从 cycle_count / cyclecount 等真实计数节点取值
    if [ ! -f "$REAL_CYCLE_FILE" ]; then
        for n in $(all_cycle_nodes); do
            case "$n" in
                *fake_cycle*) continue ;;
            esac
            got=$(cat "$n" 2>/dev/null | tr -cd '0-9')
            if [ -n "$got" ] && [ "$got" != "0" ]; then
                echo "$got" > "$REAL_CYCLE_FILE" 2>/dev/null
                break
            fi
        done
    fi

    touch "$FAKE_FLAG"
    echo "$val" > "$MODDIR/fake_value" 2>/dev/null || true

    # 云控会把真实循环数同步回来覆盖伪装值, 先禁用
    do_cloud_disable

    # 写入所有可用节点并读回验证
    # 节点路径较长, 不在面板输出(会破坏排版), 需要时用 diag 查看
    if write_all_cycle_nodes "$val"; then
        log "循环次数已伪装为: ${val}"
    else
        log "警告: 未找到可写循环节点, 该机型可能不支持伪装"
    fi
    ensure_daemon
    log "云控已禁用, 守护进程会维持伪装值"
    return 0
}

# v1.3 容量解锁 (cap)
do_cap() {
    local arg="${1:-}" val target design ok=0 failed=""

    design=$(read_design_mah)

    if [ "$arg" = "off" ]; then
        do_cap_off
        return 0
    fi

    # 目标值: 指定值 > 设计值 > 报错
    if [ -n "$arg" ]; then
        case "$arg" in
            *[!0-9]*) log "错误: 容量必须是数字(mAh), 例如: action.sh cap 5000"; return 1 ;;
        esac
        target="$arg"
    elif [ -n "$design" ]; then
        target="$design"
    else
        log "错误: 读不到设计容量, 请手动指定: action.sh cap 5000"
        return 1
    fi

    # 目标值合理性检查: 不得超过设计值的 110% (留冗余, 防止手滑填错)
    if [ -n "$design" ]; then
        local limit=$((design * 110 / 100))
        if [ "$target" -gt "$limit" ]; then
            log "错误: 目标容量超过设计值的 110%, 已拒绝"
            return 1
        fi
    fi

    local nodes n
    nodes=$(list_existing "$CAP_FULL_NODES")
    if [ -z "$nodes" ]; then
        log "未找到可写入的容量节点, 该机型可能不支持容量解锁。"
        return 1
    fi

    # 写入单位是 uAh
    local uah=$((target * 1000))
    for n in $nodes; do
        if safe_write_node "$n" "$uah"; then
            ok=$((ok + 1))
        else
            failed="$failed $n"
        fi
    done

    if [ "$ok" -gt 0 ]; then
        echo "$target" > "$CAP_FILE" 2>/dev/null || true
        touch "$CAP_FLAG" 2>/dev/null || true
        log "容量已解锁为: ${target} mAh (设计值 ${design:-未知})"
    else
        # 节点只读是内核层面的限制, 属正常现象, 不刷屏
        log "容量解锁: 该机型不支持 (节点只读, 不影响其他功能)"
        return 1
    fi
    ensure_daemon
    return 0
}

# 关闭容量解锁, 还原原值
do_cap_off() {
    local n cnt=0
    for n in $(list_existing "$CAP_FULL_NODES"); do
        restore_node "$n" && cnt=$((cnt + 1))
    done
    rm -f "$CAP_FLAG" "$CAP_FILE" 2>/dev/null
    if [ "$cnt" -gt 0 ]; then
        log "容量已还原为系统原值。"
    else
        log "未找到需要还原的容量节点(可能本就不支持)。"
    fi
    return 0
}

# 容量解锁状态查看
do_cap_status() {
    local design full n cur
    design=$(read_design_mah)
    full=$(read_full_mah)
    log "  设计容量: ${design:-未知} mAh"
    log "  系统认定: ${full:-未知} mAh"
    if [ -n "$design" ] && [ -n "$full" ] && [ "$design" -gt 0 ]; then
        log "  释放比例: $((full * 100 / design))%"
    fi
    if [ -f "$CAP_FLAG" ]; then
        log "  状态: 已解锁 ($(cat "$CAP_FILE" 2>/dev/null) mAh)"
    else
        log "  状态: 未解锁 (手动开启: action.sh cap)"
    fi
}

# v1.3 截止电压 (volt)
do_volt() {
    local arg="${1:-}"
    local design cur target n ok=0 failed=""

    design=$(read_volt_design_mv)
    cur=$(read_volt_mv)

    case "$arg" in
        off)
            do_volt_off
            return 0
            ;;
        status|"")
            log "  设计截止电压: ${design:-未知} mV"
            log "  当前截止电压: ${cur:-未知} mV"
            if [ -f "$VOLT_FLAG" ]; then
                log "  状态: 已解锁"
            else
                log "  状态: 未解锁 (开启: action.sh volt on)"
            fi
            return 0
            ;;
    esac

    # volt on / volt <数值>
    if [ "$arg" = "on" ]; then
        target="$design"
    else
        case "$arg" in
            *[!0-9]*) log "错误: 电压必须是数字(mV), 例如: action.sh volt 4450"; return 1 ;;
        esac
        target="$arg"
    fi

    if [ -z "$target" ]; then
        log "错误: 读不到设计截止电压, 请手动指定: action.sh volt 4450"
        return 1
    fi

    # 双重安全钳制
    if [ "$target" -gt "$VOLT_HARD_MAX" ]; then
        log "拒绝: 目标 ${target} mV 超过安全硬上限 ${VOLT_HARD_MAX} mV。"
        return 1
    fi
    if [ -n "$design" ] && [ "$target" -gt "$design" ]; then
        log "拒绝: 目标 ${target} mV 超过设计值 ${design} mV, 不允许超过设计值。"
        return 1
    fi

    local nodes
    nodes=$(list_existing "$VOLT_NODES")
    if [ -z "$nodes" ]; then
        log "未找到可写入的电压节点, 该机型不支持。"
        return 1
    fi

    # 判断节点单位: 原值是 uV(≥6位) 则按 uV 写, 否则按 mV 写
    for n in $nodes; do
        local raw wval
        raw=$(cat "$n" 2>/dev/null | tr -cd '0-9')
        if [ ${#raw} -ge 6 ]; then
            wval=$((target * 1000))   # uV
        else
            wval="$target"            # mV
        fi
        if safe_write_node "$n" "$wval"; then
            ok=$((ok + 1))
        else
            failed="$failed $n"
        fi
    done

    if [ "$ok" -gt 0 ]; then
        touch "$VOLT_FLAG" 2>/dev/null || true
        echo "$target" > "$MODDIR/volt_target" 2>/dev/null || true
        log "截止电压已设为: ${target} mV (设计值 ${design:-未知})"
    else
        log "截止电压: 该机型不支持 (节点只读)"
        return 1
    fi
    ensure_daemon
    return 0
}

# 关闭截止电压解锁
do_volt_off() {
    local n cnt=0
    for n in $(list_existing "$VOLT_NODES"); do
        restore_node "$n" && cnt=$((cnt + 1))
    done
    rm -f "$VOLT_FLAG" "$MODDIR/volt_target" 2>/dev/null
    [ "$cnt" -gt 0 ] && log "截止电压已还原为原值。" || log "未找到需要还原的电压节点。"
    return 0
}

# v1.3 充电电流 (curr) — 解除快充限流
# 仅恢复到设计/备份值的上限, 不超过硬上限
do_curr() {
    local arg="${1:-status}" n
    case "$arg" in
        off)
            for n in $(list_existing "$CURR_NODES"); do
                restore_node "$n"
            done
            log "充电电流上限已还原。"
            return 0
            ;;
        status|"")
            local found=0
            for n in $(list_existing "$CURR_NODES"); do
                found=1
                local v=$(cat "$n" 2>/dev/null | tr -cd '0-9')
                local ma=$((v / 1000))
                log "  $n = ${v} uA (约 ${ma} mA)"
            done
            [ "$found" = "0" ] && log "  未找到充电电流节点(该机型不支持或路径不同)。"
            return 0
            ;;
    esac
    log "用法: action.sh curr [status|off]"
}

# 诊断: 输出伪装是否生效的详细信息, 供反馈问题用
# 同时写入 action.log, 方便直接把日志文件发给作者
do_diag() {
    local out node got val
    val=$(cat "$MODDIR/fake_value" 2>/dev/null || echo 20)
    {
        echo "========== 电池解容诊断 =========="
        echo "时间: $(date)"
        echo "模块版本: $(grep '^version=' "$MODULE_PROP" 2>/dev/null | cut -d= -f2)"
        echo "机型: $(device_name)  厂商: $(getprop ro.product.manufacturer)"
        echo "内核: $(uname -r)"
        echo "Root 方案: $(root_flavor)"
        echo "用户列表: $(active_users | tr '\n' ' ')"
        echo "模块目录: $MODDIR"
        echo ""
        echo "--- 开关状态 ---"
        echo "解除充电限制: $([ -f "$PERSIST_FLAG" ] && echo 已开启 || echo 未开启)"
        echo "循环伪装:     $([ -f "$FAKE_FLAG" ] && echo "已开启 (值=$val)" || echo 未开启)"
        echo "云控禁用:     $([ -f "$CLOUD_FLAG" ] && echo 已禁用 || echo 未禁用)"
        echo "守护进程:     $(service_running && echo 运行中 || echo 未运行)"
        echo "SELinux:      $(selinux_state)  (本模块不修改此项)"
        echo ""
        echo "--- 循环节点探测 ---"
        found=0
        for node in $(all_cycle_nodes); do
            found=1
            got=$(cat "$node" 2>/dev/null | tr -cd '0-9')
            echo "  节点: $node"
            echo "    当前值: ${got:-读不到}"
            # 试探写入: 写目标值再读回, 判断是否真的可写
            echo "$val" > "$node" 2>/dev/null
            got2=$(cat "$node" 2>/dev/null | tr -cd '0-9')
            if [ "$got2" = "$val" ]; then
                echo "    写入测试: 成功 (写入 $val 后读回 $got2)"
            else
                echo "    写入测试: 失败 (写入 $val 后读回 ${got2:-空}, 该节点可能只读或无权限)"
            fi
        done
        [ "$found" = "0" ] && echo "  (未找到任何循环节点, 该机型可能不支持)"
        echo ""
        echo "--- 云控组件 ---"
        echo "  (以下组件已尝试禁用, 括号内为运行时是否仍处于启用状态的探测结果)"
        for c in $CLOUD_COMPONENTS; do
            # pm list packages -d 列出被禁用的包, 这里只做轻量探测
            short=${c%%/*}
            if pm list packages -d 2>/dev/null | grep -q "package:$short$"; then
                echo "  $c  [已禁用]"
            else
                echo "  $c  [未禁用/未知]"
            fi
        done
        echo ""
        echo "--- 电池信息 ---"
        collect_info
        echo "  机型: $(device_name)"
        echo "  电量: ${CAP}%   状态: $SCN"
        echo "  设计容量: ${DESIGN} mAh   当前容量: ${CURRENT} mAh"
        echo "  健康度: ${HEALTH}%   循环: ${CYCLE_STR}"
        echo "========== 诊断结束 =========="
    } 2>&1 | tee "$LOG_FILE"
    echo ""
    log "诊断已保存到: $LOG_FILE"
}

# 按键读取: 同 customize.sh, 只认"按下"事件并消费残留, 防止重复计数与进程堆积
# 返回: 1=音量上, 2=音量下, 0=无输入
KEY_TMP="${MODDIR}/.key_tmp"
: > "$KEY_TMP" 2>/dev/null || KEY_TMP="/tmp/.battery_unlock_key_$$"

poll_one_event() {
    : > "$KEY_TMP" 2>/dev/null
    if command -v timeout >/dev/null 2>&1; then
        timeout "${POLL_WAIT:-2}" getevent -lc 1 > "$KEY_TMP" 2>/dev/null
    else
        getevent -lc 1 > "$KEY_TMP" 2>/dev/null &
        local kpid=$!
        sleep "${POLL_WAIT:-2}"
        kill -9 "$kpid" 2>/dev/null
        wait "$kpid" 2>/dev/null
    fi
    cat "$KEY_TMP" 2>/dev/null
    : > "$KEY_TMP" 2>/dev/null
}

read_key_once() {
    command -v getevent >/dev/null 2>&1 || return 0
    local line
    line=$(poll_one_event | grep -m1 -E 'KEY_VOLUME(UP|DOWN)[[:space:]]+DOWN')
    if [ -n "$line" ]; then
        case "$line" in
            *KEY_VOLUMEUP*)   return 1 ;;
            *KEY_VOLUMEDOWN*) return 2 ;;
        esac
    fi
    return 0
}

wait_key() {
    local timeout="${1:-15}" key end
    command -v getevent >/dev/null 2>&1 || return 1
    end=$(( $(date +%s) + timeout ))
    while [ "$(date +%s)" -lt "$end" ]; do
        read_key_once
        key=$?
        [ "$key" = "1" ] && return 0
        [ "$key" = "2" ] && return 1
    done
    return 1
}

# 键盘交互配置 (不依赖 getevent, 终端里用键盘输入)
# 刷入时音量键若不灵, 装完可用此命令配置
do_setup() {
    if [ ! -t 0 ]; then
        log "当前不是交互终端, 请直接用命令配置:"
        log "  action.sh unlock / fake 5 / restore"
        return 1
    fi

    local ans
    print_info

    log "===== 配置 (键盘输入) ====="

    # 1. 解除充电限制
    printf "1) 解除充电限制? [Y/n, 回车=Y]: "
    read ans
    case "$ans" in
        [Nn]*) do_restore >/dev/null 2>&1; log "   → 已关闭充电限制解除" ;;
        *)     do_unlock; log "   → 已开启充电限制解除" ;;
    esac

    # 2. 循环伪装
    printf "2) 开启循环次数伪装? [y/N, 回车=N]: "
    read ans
    case "$ans" in
        [Yy]*)
            printf "3) 伪装为多少次? (直接输入数字, 回车=20): "
            read ans
            case "$ans" in
                ''|*[!0-9]*) ans=20 ;;
            esac
            [ "$ans" -lt 1 ] 2>/dev/null && ans=1
            do_fake "$ans"
            log "   → 循环伪装已开启, 值 = $ans"
            ;;
        *)
            rm -f "$FAKE_FLAG" "$MODDIR/fake_value" 2>/dev/null
            log "   → 循环伪装已关闭"
            ;;
    esac

    update_prop_desc
    log ""
    log "配置完成。重启后生效。"
    print_panel
}

# 按键诊断: 检测音量键能否被读到, 用于排查刷入时无法选择的问题
do_keytest() {
    log "===== 按键诊断 ====="
    if ! command -v getevent >/dev/null 2>&1; then
        log "getevent 不存在, 无法使用音量键。"
        log "请在终端用键盘配置: action.sh setup"
        return 1
    fi
    log "getevent 存在。请在 5 秒内按一次音量键..."
    local key end
    end=$(( $(date +%s) + 5 ))
    while [ "$(date +%s)" -lt "$end" ]; do
        read_key_once
        key=$?
        if [ "$key" = "1" ]; then
            log "✓ 检测到: 音量上"
            return 0
        elif [ "$key" = "2" ]; then
            log "✓ 检测到: 音量下"
            return 0
        fi
    done
    log "✗ 5 秒内未检测到音量键。"
    log "可能原因: 无读 /dev/input 权限、SELinux 限制、或环境不支持。"
    log "解决: 在终端用键盘配置 → action.sh setup"
    return 1
}

case "${1:-}" in
    help)
        do_help
        ;;
    setup)
        do_setup
        ;;
    keytest)
        do_keytest
        ;;
    cloud)
        shift
        do_cloud "${1:-}"
        print_panel
        ;;
    cloudmode)
        shift
        do_cloudmode "${1:-}"
        ;;
    versions)
        do_versions
        ;;
    api)
        do_api
        ;;
    chargestat)
        do_chargestat
        ;;
    chargelog)
        shift
        case "${1:-}" in
            diag)  do_chargelog_diag ;;
            on|off) do_chargelog_switch "${1:-}" ;;
            *)     do_chargelog ;;
        esac
        ;;
    clearlog)
        do_clearlog
        ;;
    diag)
        do_diag
        ;;
    scan)
        do_scan
        ;;
    cap)
        shift
        arg="${1:-}"
        if [ "$arg" = "status" ]; then
            # 仅查看容量状态
            update_prop_desc
            print_panel
            log "===== 容量解锁 ====="
            do_cap_status
        else
            # 不带参数 = 按设计值解锁; 带数字 = 自定义; off = 还原
            do_cap "$arg" || exit 1
            update_prop_desc
            print_panel
        fi
        ;;
    volt)
        shift
        do_volt "${1:-status}"
        ;;
    curr)
        shift
        do_curr "${1:-status}"
        ;;
    sdv)
        shift
        do_sdv "${1:-}" "${2:-}"
        ;;
    bov)
        shift
        do_bov "${1:-}" "${2:-}"
        ;;
    selinux)
        shift
        do_selinux "${1:-}"
        ;;
    json)
        do_api
        ;;
    sessions)
        do_sessions
        ;;
    fixcloud)
        do_fixcloud
        log ""
        log "提示: 若充电提示音/游戏工具箱仍失效, 这是旧版本清空 joyose"
        log "      数据造成的(不可逆), 需在 设置 -> 声音与振动 里重新开启。"
        update_prop_desc
        ;;
    baa)
        shift
        case "${1:-}" in
            fix)     do_baa_fix ;;
            restore) do_baa_restore ;;
            *)       do_baa ;;
        esac
        ;;
    pd)
        shift
        do_pd "${1:-}"
        ;;
    powersave)
        shift
        do_powersave "${1:-}"
        ;;
    clearpk)
        do_clearpk
        ;;
    cloudforce)
        do_cloud_force
        ;;
    webui)
        # WebUI 不存在时的兜底: 直接输出状态
        do_json
        ;;
    lock)
        do_lock
        ;;
    unlock)
        do_unlock
        update_prop_desc
        print_panel
        ;;
    restore)
        do_restore
        update_prop_desc
        print_panel
        ;;
    status)
        update_prop_desc
        print_panel
        ;;
    fake)
        shift
        do_fake "${1:-20}" || exit 1
        update_prop_desc
        print_panel
        ;;
    author)
        # 不自动跳转浏览器, 只输出主页地址 (避免操作后被强制拉起页面)
        log ""
        log "$SUBLINE"
        log "  作者: 浔念6"
        log "  酷安: $COOLAPK_URL"
        log ""
        ;;
    update)
        update_prop_desc
        ;;
    *)
        # 无参数: 一律非交互 —— 直接解除限制并显示面板。
        #
        # 不能靠 [ -t 0 ] 判断是否交互: KernelSU 点「操作」按钮时,
        # stdin 有可能被判为 tty, 一旦进入 do_setup 就会阻塞在 read
        # 上等一个永远不会到来的输入, 管理器侧表现为"运行失败"。
        # (此前正是这么写的, 导致大量用户点操作按钮无响应。)
        #
        # 需要键盘交互配置请用显式命令: action.sh setup
        do_unlock
        update_prop_desc
        print_panel
        log ""
        log "提示: 交互配置请执行 action.sh setup"
        ;;
esac

exit 0
