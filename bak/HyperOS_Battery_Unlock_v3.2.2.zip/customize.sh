#!/system/bin/sh

SKIPUNZIP=0

# 注意: 这里不要执行 setenforce 0

MODPATH="${MODPATH:-$1}"

# set_perm 兼容 (Magisk/KSU 提供, 否则自建)
if ! command -v set_perm >/dev/null 2>&1; then
    set_perm() {
        chown "${2}:${3}" "$1" 2>/dev/null || true
        chmod "$4" "$1" 2>/dev/null || true
    }
fi

ui_print() {
    if [ -n "${OUTFD:-}" ] && [ -w "/proc/self/fd/$OUTFD" ]; then
        echo "ui_print $1" >&"$OUTFD"
    else
        echo "$1"
    fi
}

[ -f "$MODPATH/action.sh" ] && set_perm "$MODPATH/action.sh" 0 0 0755
[ -f "$MODPATH/service.sh" ] && set_perm "$MODPATH/service.sh" 0 0 0755
[ -f "$MODPATH/post-fs-data.sh" ] && set_perm "$MODPATH/post-fs-data.sh" 0 0 0755
# WebUI 目录: 管理器需读取 index.html 才能显示网页界面
[ -d "$MODPATH/webroot" ] && chmod -R 0755 "$MODPATH/webroot" 2>/dev/null

# 按键读取
KEY_TMP="${MODPATH}/.key_tmp"
: > "$KEY_TMP" 2>/dev/null || KEY_TMP="/tmp/.battery_unlock_key_$$"

# 单次探测 (关键重写):
poll_one_event() {
    : > "$KEY_TMP" 2>/dev/null
    if command -v timeout >/dev/null 2>&1; then
        # 优先用 timeout: 按下键后 getevent(-c 1)自行退出, timeout 立即返回,
        # 无需空等; 未按键则等到上限后被终止。避免了轮询判断僵尸进程的坑。
        timeout "${POLL_WAIT:-2}" getevent -lc 1 > "$KEY_TMP" 2>/dev/null
    else
        # 无 timeout 时退化为固定等待 (不会卡死, 但响应略慢)
        getevent -lc 1 > "$KEY_TMP" 2>/dev/null &
        local kpid=$!
        sleep "${POLL_WAIT:-2}"
        kill -9 "$kpid" 2>/dev/null
        wait "$kpid" 2>/dev/null
    fi
    cat "$KEY_TMP" 2>/dev/null
    : > "$KEY_TMP" 2>/dev/null
}

read_key_once() {
    command -v getevent >/dev/null 2>&1 || return 0
    # 只认"按下"事件(行尾为 DOWN), 忽略抬起(UP)与同步(SYN)
    local line
    line=$(poll_one_event | grep -m1 -E 'KEY_VOLUME(UP|DOWN)[[:space:]]+DOWN')
    if [ -n "$line" ]; then
        case "$line" in
            *KEY_VOLUMEUP*)   return 1 ;;
            *KEY_VOLUMEDOWN*) return 2 ;;
        esac
    fi
    return 0
}

# 是否支持按键交互
HAS_KEY=0
command -v getevent >/dev/null 2>&1 && HAS_KEY=1
# 菜单是否走了默认值 (用于结束时提示可用键盘配置)
MENU_USED_DEFAULT=0

# 交互组件 (结果用全局变量返回, 避免命令替换污染 stdout)

# 是/否选择 → ASK_RESULT = 1(开启) 或 0(关闭)
# 超时可用环境变量 KEY_TIMEOUT 覆盖 (测试/高级用户), 默认取传入值
ask_yes_no() {
    local prompt="$1" default="$2"
    local timeout="${KEY_TIMEOUT:-$3}"
    local t key
    ASK_RESULT="$default"
    ui_print "  $prompt"
    if [ "$default" = "1" ]; then
        ui_print "    音量上 = 开启    音量下 = 关闭    (默认: 开启)"
    else
        ui_print "    音量上 = 开启    音量下 = 关闭    (默认: 关闭)"
    fi
    ui_print "    ${timeout} 秒无操作自动采用默认值"
    if [ "$HAS_KEY" = "0" ]; then
        MENU_USED_DEFAULT=1
        ui_print "    (未检测到按键支持, 使用默认值)"
        return
    fi
    # 用真实时间(秒)计时, 而非探测次数:
    # 一次物理按键会产生多个事件(DOWN/SYN/UP/SYN), 残留事件消费很快,
    # 若按次数计时会挤占用户实际操作时间
    local end
    end=$(( $(date +%s) + timeout ))
    while [ "$(date +%s)" -lt "$end" ]; do
        read_key_once
        key=$?
        if [ "$key" = "1" ]; then
            ASK_RESULT=1
            ui_print "    → 已选择: 开启"
            return
        elif [ "$key" = "2" ]; then
            ASK_RESULT=0
            ui_print "    → 已选择: 关闭"
            return
        fi
    done
    MENU_USED_DEFAULT=1
    ui_print "    → 超时, 采用默认值"
}

# 预设值循环选择 → SELECTED_VALUE
# 音量上 = 切换下一个预设, 音量下 = 确认当前值
# 云控策略三选一: 音量上循环切换, 音量下确认
select_cloud_mode() {
    local timeout="${KEY_TIMEOUT:-$1}"
    local cur="full" key next end
    CLOUD_MODE="full"
    ui_print "  云控处理策略"
    ui_print "    当前: full"
    ui_print "    音量上 = 切换 (full → clear → off)    音量下 = 确认"
    ui_print "    ${timeout} 秒无操作自动使用 full"
    ui_print "    full  硬控: 禁用云控组件并清除数据"
    ui_print "    clear 软控: 只清数据, 保留云控组件可用"
    ui_print "    off   关闭: 不处理云控, 仅用循环伪装"
    if [ "$HAS_KEY" = "0" ]; then
        ui_print "    (未检测到按键支持, 使用默认 full)"
        CLOUD_MODE="full"
        return
    fi
    end=$(( $(date +%s) + timeout ))
    while [ "$(date +%s)" -lt "$end" ]; do
        read_key_once
        key=$?
        if [ "$key" = "1" ]; then
            case "$cur" in
                full)  next="clear" ;;
                clear) next="off" ;;
                *)     next="full" ;;
            esac
            cur="$next"
            ui_print "    → 当前: $cur"
            end=$(( $(date +%s) + timeout ))
        elif [ "$key" = "2" ]; then
            CLOUD_MODE="$cur"
            ui_print "    → 确认使用: $cur"
            return
        fi
    done
    CLOUD_MODE="$cur"
    ui_print "    → 超时, 使用当前值: $cur"
}

select_preset_value() {
    local presets="20 5 50 100"
    local timeout="${KEY_TIMEOUT:-$1}"
    local t key cur next found p
    SELECTED_VALUE=20
    cur=20
    ui_print "  循环伪装值"
    ui_print "    当前值: $cur"
    ui_print "    音量上 = 切换 (20 → 5 → 50 → 100)    音量下 = 确认使用"
    ui_print "    ${timeout} 秒无操作自动使用 20"
    ui_print "    提示: 安装后可用 action.sh fake N 设为任意值"
    if [ "$HAS_KEY" = "0" ]; then
        ui_print "    (未检测到按键支持, 使用默认值 20)"
        SELECTED_VALUE=20
        return
    fi
    local end
    end=$(( $(date +%s) + timeout ))
    while [ "$(date +%s)" -lt "$end" ]; do
        read_key_once
        key=$?
        if [ "$key" = "1" ]; then
            next=""
            found=0
            for p in $presets; do
                if [ "$found" = "1" ]; then next="$p"; break; fi
                [ "$p" = "$cur" ] && found=1
            done
            [ -z "$next" ] && next=20
            cur="$next"
            ui_print "    → 当前值: $cur"
            end=$(( $(date +%s) + timeout ))   # 每次操作后重新给足时间
        elif [ "$key" = "2" ]; then
            SELECTED_VALUE="$cur"
            ui_print "    → 确认使用: $cur"
            return
        fi
    done
    SELECTED_VALUE="$cur"
    ui_print "    → 超时, 使用当前值: $cur"
}

# 等待退出: 任意音量键或超时后继续
wait_exit() {
    local timeout="${KEY_TIMEOUT:-$1}"
    local t key
    if [ "$HAS_KEY" = "0" ]; then
        return
    fi
    ui_print "  按任意音量键退出 (或 ${timeout} 秒后自动继续)..."
    local end
    end=$(( $(date +%s) + timeout ))
    while [ "$(date +%s)" -lt "$end" ]; do
        read_key_once
        key=$?
        if [ "$key" != "0" ]; then
            ui_print "  → 已退出选择, 开始安装"
            return
        fi
    done
    ui_print "  → 超时, 自动继续"
}

# 0. 厂商校验 (仅米系)
ui_print "===================================="
ui_print "  解除锁容 v3.2.2"
ui_print "===================================="

MANUFACTURER=$(getprop ro.product.manufacturer)
[ -z "$MANUFACTURER" ] && MANUFACTURER=$(getprop ro.product.brand)
MANUFACTURER=$(echo "$MANUFACTURER" | tr '[:upper:]' '[:lower:]')

case "$MANUFACTURER" in
    *xiaomi*|*redmi*|*poco*)
        ui_print "厂商: $MANUFACTURER (支持)"
        ;;
    *)
        ui_print "当前设备厂商: $MANUFACTURER"
        ui_print "本模块仅支持小米 / 红米 / POCO 设备, 已中止安装"
        rm -rf "$MODPATH"
        exit 1
        ;;
esac

DEVICE=$(getprop ro.product.device)
ui_print "设备: $DEVICE"
ui_print "内核: $(uname -r)"

# 1. 多项选择菜单 (逐项选择, 每项独立)
ui_print ""
ui_print "===== 安装配置 (逐项选择) ====="
if [ "$HAS_KEY" = "0" ]; then
    ui_print "(未检测到按键支持, 全部使用默认配置)"
fi

ui_print ""
ui_print "[1/3]"
ask_yes_no "解除充电限制 (80% 上限、清除学习数据)" 1 8
UNLOCK_CHOICE="$ASK_RESULT"

ui_print ""
ui_print "[2/3]"
ask_yes_no "开启循环次数伪装" 0 8
FAKE_CHOICE="$ASK_RESULT"

FAKE_VALUE=20
if [ "$FAKE_CHOICE" = "1" ]; then
    ui_print ""
    select_preset_value 15
    FAKE_VALUE="$SELECTED_VALUE"
fi

# 说明: 容量解锁不再出现在安装菜单。
# 多数机型的 charge_full 是内核只读属性, 刷入时必然失败,
# 显示在菜单里只会造成"未解锁"的困惑。需要时手动 action.sh cap。

ui_print ""
ui_print "[3/3]"
select_cloud_mode 15

# 2. 汇总 + 按音量键退出
ui_print ""
ui_print "===== 配置汇总 ====="
if [ "$UNLOCK_CHOICE" = "1" ]; then
    ui_print "  解除充电限制: 开启"
else
    ui_print "  解除充电限制: 关闭"
fi
if [ "$FAKE_CHOICE" = "1" ]; then
    ui_print "  循环伪装: 开启 (值 = $FAKE_VALUE)"
else
    ui_print "  循环伪装: 关闭"
fi
ui_print "  云控策略: $CLOUD_MODE"
ui_print ""
wait_exit 15

# 3. 应用配置
if [ "$UNLOCK_CHOICE" = "1" ]; then
    ui_print ""
    ui_print "== 应用: 解除充电限制 =="
    # 交给 action.sh unlock: 包名优先 + 多手段尝试, 避免只禁用
    # 写死的组件名(很多机型上并不存在)而实际未生效
    if [ -x "$MODPATH/action.sh" ]; then
        out=$(sh "$MODPATH/action.sh" unlock 2>&1)
        echo "$out" | grep -E "已解除|未找到" | head -1 | while read -r l; do ui_print "  $l"; done
    else
        resetprop -n persist.sys.charging_stop_level 100 2>/dev/null || true
        touch "$MODPATH/unlocked.flag" 2>/dev/null || true
        ui_print "  充电限制已解除"
    fi
else
    ui_print ""
    ui_print "== 跳过: 解除充电限制 (之后可用 action.sh unlock 开启) =="
    rm -f "$MODPATH/unlocked.flag" 2>/dev/null
fi

if [ "$FAKE_CHOICE" = "1" ]; then
    # 走 action.sh fake: 内部会先备份真实循环值(便于以后还原), 再写入伪装值
    if [ -x "$MODPATH/action.sh" ]; then
        sh "$MODPATH/action.sh" fake "$FAKE_VALUE" >/dev/null 2>&1 || true
        [ -f "$MODPATH/fake_enabled.flag" ] || touch "$MODPATH/fake_enabled.flag" 2>/dev/null
        [ -f "$MODPATH/fake_value" ] || echo "$FAKE_VALUE" > "$MODPATH/fake_value" 2>/dev/null
    else
        echo "$FAKE_VALUE" > "$MODPATH/fake_value" 2>/dev/null || true
        touch "$MODPATH/fake_enabled.flag" 2>/dev/null || true
    fi
    ui_print "  循环伪装: 已开启 (值 = $FAKE_VALUE)"
else
    rm -f "$MODPATH/fake_value" "$MODPATH/fake_enabled.flag" 2>/dev/null
    ui_print "  循环伪装: 未开启"
fi

# 应用云控策略
echo "$CLOUD_MODE" > "$MODPATH/cloud_mode" 2>/dev/null || true
case "$CLOUD_MODE" in
    off)
        ui_print "  云控策略: off (不处理云控)"
        ;;
    *)
        if [ -x "$MODPATH/action.sh" ]; then
            sh "$MODPATH/action.sh" cloudmode "$CLOUD_MODE" >/dev/null 2>&1 || true
        fi
        case "$CLOUD_MODE" in
            full)  ui_print "  云控策略: full (已禁用云控组件并清数据)" ;;
            clear) ui_print "  云控策略: clear (已清数据, 组件保留可用)" ;;
        esac
        ;;
esac

# 充电记录默认启用, 供 WebUI 绘制充电曲线
touch "$MODPATH/charge_log_enabled.flag" 2>/dev/null || true

rm -f "$MODPATH/cap_enabled.flag" "$MODPATH/cap_value" 2>/dev/null
# 初始化模块描述
ui_print ""
ui_print "== 初始化模块描述 =="
if [ -x "$MODPATH/action.sh" ]; then
    sh "$MODPATH/action.sh" update >/dev/null 2>&1 || true
    ui_print "  模块描述已初始化"
fi

rm -f "$KEY_TMP" 2>/dev/null

ui_print ""
ui_print "安装完成。请重启设备, 之后完整充电一次。"
if [ -f "$MODPATH/webroot/index.html" ]; then
    ui_print ""
    ui_print "重启后可在管理器中点击模块的网页按钮打开 WebUI。"
fi
ui_print ""
if [ "$HAS_KEY" = "0" ] || [ "$MENU_USED_DEFAULT" = "1" ]; then
    ui_print "提示: 若刷入时音量键无法选择, 可在终端用键盘配置:"
    ui_print "  action.sh setup        (键盘交互配置)"
    ui_print "  action.sh fake 5       (直接伪装为 5 次)"
fi
ui_print "如需恢复, 在管理器中卸载本模块并重启即可。"
ui_print ""
ui_print "作者: 浔念6  https://www.coolapk.com/u/37786723"
exit 0
