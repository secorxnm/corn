#!/system/bin/sh

MODDIR=${0%/*}
[ -z "$MODDIR" ] && MODDIR="/data/adb/modules/hyperos_battery_unlock"

MODULE_PROP="$MODDIR/module.prop"
FAKE_FLAG="$MODDIR/fake_enabled.flag"
PERSIST_FLAG="$MODDIR/unlocked.flag"
CLOUD_FLAG="$MODDIR/cloud_disabled.flag"
CLOUD_MODE_FILE="$MODDIR/cloud_mode"
CHARGE_LOG="$MODDIR/charge_log.jsonl"
CHARGE_LOG_FLAG="$MODDIR/charge_log_enabled.flag"
SESSIONS="$MODDIR/charge_sessions.jsonl"    # 已结算的充电会话(供统计)
CHG_STATE="$MODDIR/.charging"               # 会话开始时间戳(存在=正在充电)
CHG_FROM="$MODDIR/.charging.from"           # 会话起始电量
CHG_LAST="$MODDIR/.charging.last"           # 最近一次采样电量
CHG_LASTT="$MODDIR/.charging.lastt"         # 最近一次采样时间
CHG_N="$MODDIR/.charging.n"                 # 本会话采样点数
CHG_SUMP="$MODDIR/.charging.sump"           # 本会话功率累加(mW), 用于算平均功率
CHG_MAXP="$MODDIR/.charging.maxp"           # 本会话峰值功率(mW)
CHG_NP="$MODDIR/.charging.np"               # 本会话有效功率采样数
PD_FLAG="$MODDIR/pd_enabled.flag"           # PPS 认证解锁
SDV_FLAG="$MODDIR/sdv_enabled.flag"         # 关机电压
SDV_FILE="$MODDIR/sdv_value"
BOV_FLAG="$MODDIR/bov_enabled.flag"         # 开机电压
BOV_FILE="$MODDIR/bov_value"
FAKE_FILE="$MODDIR/fake_value"
REAL_CYCLE_FILE="$MODDIR/real_cycle"
CAP_FLAG="$MODDIR/cap_enabled.flag"
CAP_FILE="$MODDIR/cap_value"
VOLT_FLAG="$MODDIR/volt_enabled.flag"
BACKUP_DIR="$MODDIR/backup"
LOCK="$MODDIR/.service.pid"

# sysfs 根目录: 默认 /sys, 测试时可设为 mock 目录
SYS_ROOT="${SYS_ROOT:-}"

# 轮询间隔(秒)。伪装值维持需要较高频, 但写入是"检测式"的, 开销很低。
INTERVAL="${SERVICE_INTERVAL:-30}"
# 开机后首轮前的等待(秒), 等系统电池服务就绪。可用 BOOT_DELAY 覆盖(测试用)
BOOT_DELAY="${BOOT_DELAY:-5}"
# 云控禁用 / 解容重建的间隔 = INTERVAL × HEAVY_TICK
HEAVY_TICK="${SERVICE_HEAVY_TICK:-10}"   # 10 * 30s = 5 分钟

# 循环节点候选 (与 action.sh 保持一致)
CYCLE_NODES="
/sys/class/qcom-battery/fake_cycle
/sys/class/xm_power/fg_master/cyclecount
/sys/class/xm_power/cyclecount
/sys/class/power_supply/battery/cycle_count
/sys/class/power_supply/battery/fg_cycle_count
/sys/class/power_supply/battery/batt_cycle_count
/sys/class/power_supply/bms/cycle_count
"

# v1.3 容量 / 电压节点 (与 action.sh 保持一致)
# 这些节点重启后内核会重置, 必须在开机时重新应用
CAP_FULL_NODES="
/sys/class/power_supply/battery/charge_full
/sys/class/power_supply/bms/charge_full
"
VOLT_NODES="
/sys/class/power_supply/battery/constant_charge_voltage_max
/sys/class/power_supply/battery/voltage_max
/sys/class/power_supply/main/constant_charge_voltage_max
/sys/class/power_supply/bms/voltage_max
"
VOLT_HARD_MAX=4500

# 解容目标 (与 action.sh 保持一致)
LOCK_COMPONENTS="
com.miui.securitycenter/com.miui.powercenter.provider.PowerSaveService
com.miui.securitycenter/.powercenter.provider.PowerSaveService
com.miui.powercenter/.provider.PowerSaveService
com.miui.powercenter/com.miui.powercenter.provider.PowerSaveService
"
LOCK_PACKAGES="
com.miui.powerkeeper
com.xiaomi.joyose
com.miui.analytics
com.miui.daemon
com.xiaomi.powerchecker
com.xiaomi.miservice
"
LEARN_DIRS="
/data/vendor/batteryantiaging
/data/system/battery_config
/data/misc/batteryantiaging
/data/system/cloud_battery_config
/data/system/battery_cloud_config
/data/misc/battery_cloud
"

pkg_of() { echo "${1%%/*}"; }
# pm list 返回空时视为"可能存在", 继续尝试, 避免 pm 异常导致解容失效
# 包列表缓存: 同 action.sh, 避免每次 pm list packages(真机 1~3 秒/次)
PKG_CACHE=""; PKG_LOADED=0
DISABLED_CACHE=""; DISABLED_LOADED=0
pkg_load(){ [ "$PKG_LOADED" = "1" ] && return 0; PKG_CACHE=$(pm list packages 2>/dev/null); PKG_LOADED=1; }
disabled_load(){ [ "$DISABLED_LOADED" = "1" ] && return 0; DISABLED_CACHE=$(pm list packages -d 2>/dev/null); DISABLED_LOADED=1; }

pkg_exists() {
    local p
    p=$(pkg_of "$1")
    [ -z "$p" ] && return 1
    pkg_load
    [ -z "$PKG_CACHE" ] && return 0
    echo "$PKG_CACHE" | grep -qx "package:$p"
}
is_disabled() {
    local p
    p=$(pkg_of "$1")
    disabled_load
    [ -z "$DISABLED_CACHE" ] && return 1
    echo "$DISABLED_CACHE" | grep -qx "package:$p"
}
try_disable() {
    local t="$1"
    pm disable "$t" >/dev/null 2>&1 && return 0
    case "$t" in
        */*) : ;;
        *) pm disable-user --user 0 "$t" >/dev/null 2>&1 && return 0 ;;
    esac
    pm suspend "$t" >/dev/null 2>&1 && return 0
    return 1
}

# 云控组件 (与 action.sh 保持一致)
CLOUD_COMPONENTS="
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateReceiver
com.miui.powerkeeper/com.miui.powerkeeper.cloudcontrol.CloudUpdateJobService
com.miui.powerkeeper/com.miui.powerkeeper.ui.CloudInfoActivity
com.miui.daemon/com.miui.daemon.performance.cloudcontrol.CloudControlSyncService
com.xiaomi.joyose
com.miui.analytics
"

# 不含 joyose: pm clear 会清掉用户设置(充电提示音等)且不可逆,
# 自动守护只停用组件, 不清数据。
CLOUD_CLEAR_PKGS="
com.miui.powerkeeper

com.miui.analytics
"

mkdir -p "$MODDIR" 2>/dev/null

# 接管: 终止上一个守护实例
# 模块更新或重复启动时, 旧实例仍在按它启动时读到的旧值写入,
# 会让用户新改的配置被覆盖回去。这里直接终止旧的, 由本次接管。
if [ -f "$LOCK" ]; then
    old=$(cat "$LOCK" 2>/dev/null)
    if [ -n "$old" ] && [ "$old" != "$$" ] && [ -d "/proc/$old" ]; then
        kill -9 "$old" 2>/dev/null
        sleep 1
    fi
fi

wait_until_login() {
    # 加超时保护: getprop 异常时不至于永久卡住
    local i=0
    while [ "$(getprop sys.boot_completed)" != "1" ]; do
        i=$((i + 1))
        [ "$i" -ge 180 ] && return 0
        sleep 1
    done
}

# 写入循环值 (仅当当前值与目标不一致时才写)
write_cycle_if_needed() {
    local val="$1" n cur
    [ -z "$val" ] && return 1
    for n in $CYCLE_NODES; do
        [ -f "$SYS_ROOT$n" ] || continue
        cur=$(cat "$SYS_ROOT$n" 2>/dev/null | tr -cd '0-9')
        [ "$cur" = "$val" ] && continue
        chmod 666 "$SYS_ROOT$n" 2>/dev/null || true
        echo "$val" > "$SYS_ROOT$n" 2>/dev/null || true
    done
}

# 伪装被关闭后, 还原真实循环值 (若之前备份过)
restore_real_cycle() {
    local real
    [ -f "$REAL_CYCLE_FILE" ] || return 0
    real=$(cat "$REAL_CYCLE_FILE" 2>/dev/null | tr -cd '0-9')
    if [ -n "$real" ]; then
        write_cycle_if_needed "$real"
    fi
    rm -f "$REAL_CYCLE_FILE" 2>/dev/null
}

# v1.3: 重新应用容量解锁 / 截止电压
# 这类节点每次开机都会被内核重置, 必须重新写入才能持续生效。
# 仅在开关开启时执行; 写入前自动备份原值(由 backup_node 保证只备一次)。
backup_node() {
    local node="$1" name val
    # 与 action.sh 保持一致: 去掉 SYS_ROOT 前缀, 否则卸载时找不到备份
    name=$(echo "${node#$SYS_ROOT}" | sed 's|/|_|g')
    mkdir -p "$BACKUP_DIR" 2>/dev/null
    [ -f "$BACKUP_DIR/$name" ] && return 0
    val=$(cat "$node" 2>/dev/null | tr -cd '0-9')
    [ -n "$val" ] && echo "$val" > "$BACKUP_DIR/$name" 2>/dev/null
}

write_node_if_needed() {
    local node="$1" val="$2" cur
    [ -f "$node" ] || return 1
    cur=$(cat "$node" 2>/dev/null | tr -cd '0-9')
    [ "$cur" = "$val" ] && return 0
    backup_node "$node"
    chmod 644 "$node" 2>/dev/null || true
    echo "$val" > "$node" 2>/dev/null || true
}

apply_capacity() {
    local val node uah
    [ -f "$CAP_FLAG" ] || return 0
    val=$(cat "$CAP_FILE" 2>/dev/null | tr -cd '0-9')
    [ -z "$val" ] && return 0
    uah=$((val * 1000))
    for node in $CAP_FULL_NODES; do
        write_node_if_needed "${SYS_ROOT}$node" "$uah"
    done
}

apply_voltage() {
    local target node raw wval
    [ -f "$VOLT_FLAG" ] || return 0
    # 目标值取自备份目录里的"原始设计值"更安全; 这里沿用开机时的设计值
    # 说明: 用户在 action.sh volt 中设定的值已写入节点, 重启后需重设。
    # 为避免重复记录, 目标值存放在 volt_target 文件(由 action.sh 写入)
    target=$(cat "$MODDIR/volt_target" 2>/dev/null | tr -cd '0-9')
    [ -z "$target" ] && return 0
    [ "$target" -gt "$VOLT_HARD_MAX" ] && return 0
    for node in $VOLT_NODES; do
        [ -f "${SYS_ROOT}$node" ] || continue
        raw=$(cat "${SYS_ROOT}$node" 2>/dev/null | tr -cd '0-9')
        if [ ${#raw} -ge 6 ]; then
            wval=$((target * 1000))
        else
            wval="$target"
        fi
        write_node_if_needed "${SYS_ROOT}$node" "$wval"
    done
}

# 禁用云控组件
cloud_mode() {
    local m
    m=$(cat "$CLOUD_MODE_FILE" 2>/dev/null | tr -cd 'a-z')
    case "$m" in
        full|clear|off) : ;;
        *) m="full" ;;
    esac
    echo "$m"
}

# 按策略处理云控: full=禁用+清数据, clear=只清数据, off=不处理
disable_cloud() {
    local mode c
    mode=$(cloud_mode)
    [ "$mode" = "off" ] && return 0
    if [ "$mode" = "clear" ]; then
        for c in $CLOUD_CLEAR_PKGS; do
            pm clear "$c" >/dev/null 2>&1 || true
        done
        return 0
    fi
    for c in $CLOUD_COMPONENTS; do
        pm disable "$c" >/dev/null 2>&1 || true
    done
    for c in $CLOUD_CLEAR_PKGS; do
        pm clear "$c" >/dev/null 2>&1 || true
    done
}

# 重建解容: 与 action.sh 保持同一套目标(包名优先), 只做不输出
rebuild_unlock() {
    local t
    resetprop -n persist.sys.charging_stop_level 100 2>/dev/null || true
    for t in $LOCK_COMPONENTS $LOCK_PACKAGES; do
        pkg_exists "$t" || continue
        is_disabled "$t" && continue
        try_disable "$t"
    done
    for d in $LEARN_DIRS; do
        [ -d "$d" ] && rm -rf "$d"/* >/dev/null 2>&1 || true
    done
}

# 电池节点探测
# 扫描 sysfs 发现循环节点(与 action.sh 同一套逻辑, 覆盖硬编码清单外的机型)
cycle_scan() {
    local d f
    for d in "$SYS_ROOT"/sys/class/power_supply/*/ \
             "$SYS_ROOT"/sys/class/qcom-battery/ \
             "$SYS_ROOT"/sys/class/xm_power/ \
             "$SYS_ROOT"/sys/class/xm_power/fg_master/ \
             "$SYS_ROOT"/sys/class/bms/; do
        [ -d "$d" ] || continue
        for f in "$d"*cycle* "$d"*Cycle*; do
            [ -f "$f" ] || continue
            echo "$f"
        done
    done
}
all_cycle_nodes() {
    local n
    for n in $CYCLE_NODES; do
        [ -f "$SYS_ROOT$n" ] && echo "$SYS_ROOT$n"
    done
    cycle_scan
}

find_bat() {
    local b
    for b in battery battery0 Battery; do
        [ -d "$SYS_ROOT/sys/class/power_supply/$b" ] && { echo "$SYS_ROOT/sys/class/power_supply/$b"; return 0; }
    done
    for d in "$SYS_ROOT"/sys/class/power_supply/*/; do
        [ -f "${d}capacity" ] && { echo "${d%/}"; return 0; }
    done
    echo "$SYS_ROOT/sys/class/power_supply/battery"
}

SAMPLE_COUNT=0

# ===== 充电采样与会话统计 =====
#
# 需求: 充完电自动生成一次充电的过程记录, 并统计时长与充入量。
#
# 设计:
#   一次"插上到拔掉"= 一个会话。充电中持续采样写 jsonl;
#   检测到拔电(状态不再是充电)时结算: 起止电量、时长、充入量、采样点数,
#   写入 sessions 文件。WebUI 直接读它做统计展示。
#
# 会话状态用文件保存而非内存变量: 守护进程被杀或重启后仍能正确结算,
# 不会丢失"上一轮正在充电"的事实。

# 单个会话超过 12 小时视为异常(如开机后残留状态), 强制结算重开,
# 否则时长会被算成几十小时。
MAX_SESSION_SEC=43200

settle_session() {
    local sT eT a b n mins gain
    local sump maxp np avgP=0 peakP=0 speed=0
    sT=$(cat "$CHG_STATE" 2>/dev/null | tr -cd '0-9')
    eT=$(cat "$CHG_LASTT" 2>/dev/null | tr -cd '0-9')
    a=$(cat "$CHG_FROM" 2>/dev/null | tr -cd '0-9')
    b=$(cat "$CHG_LAST" 2>/dev/null | tr -cd '0-9')
    n=$(cat "$CHG_N" 2>/dev/null | tr -cd '0-9')
    sump=$(cat "$CHG_SUMP" 2>/dev/null | tr -cd '0-9')
    maxp=$(cat "$CHG_MAXP" 2>/dev/null | tr -cd '0-9')
    np=$(cat "$CHG_NP" 2>/dev/null | tr -cd '0-9')
    rm -f "$CHG_STATE" "$CHG_FROM" "$CHG_LAST" "$CHG_LASTT" "$CHG_N" \
          "$CHG_SUMP" "$CHG_MAXP" "$CHG_NP" 2>/dev/null

    if [ -z "$sT" ] || [ -z "$eT" ]; then return 0; fi
    [ -z "$a" ] && a=0
    [ -z "$b" ] && b="$a"
    [ -z "$n" ] && n=0
    if [ "$eT" -le "$sT" ]; then mins=0; else mins=$(( (eT - sT) / 60 )); fi
    if [ "$b" -ge "$a" ]; then gain=$((b - a)); else gain=0; fi
    # 极短且采样极少的片段不记(误触充电线等), 避免噪声
    if [ "$mins" -lt 1 ] && [ "$n" -lt 3 ]; then return 0; fi
    # 平均/峰值功率(mW)与平均充电速度(%/分钟, 乘 10 存整数)
    [ -z "$sump" ] && sump=0
    [ -z "$maxp" ] && maxp=0
    [ -z "$np" ] && np=0
    if [ "$np" -gt 0 ]; then avgP=$((sump / np)); fi
    peakP=$maxp
    if [ "$mins" -gt 0 ]; then
        speed=$(awk -v g="$gain" -v m="$mins" 'BEGIN{printf "%d", (g*10)/m}')
    fi
    [ -z "$speed" ] && speed=0
    printf '{"s":%s,"e":%s,"from":%s,"to":%s,"mins":%s,"n":%s,"avgP":%s,"peakP":%s,"speed":%s}\n' \
        "$sT" "$eT" "$a" "$b" "$mins" "$n" "$avgP" "$peakP" "$speed" \
        >> "$SESSIONS" 2>/dev/null || true
    # 会话数上限, 保留最近 100 条
    if [ -f "$SESSIONS" ]; then
        local c
        c=$(wc -l < "$SESSIONS" 2>/dev/null | tr -d ' ')
        if [ "${c:-0}" -gt 100 ]; then
            tail -n 100 "$SESSIONS" > "$SESSIONS.tmp" 2>/dev/null && \
                mv "$SESSIONS.tmp" "$SESSIONS" 2>/dev/null || true
        fi
    fi
    return 0
}

charge_sample() {
    [ ! -f "$CHARGE_LOG_FLAG" ] && return 0
    local bat st lv t is_chg n sT
    bat=$(find_bat)
    st=$(cat "$bat/status" 2>/dev/null | tr -d ' \r' | tr 'A-Z' 'a-z')
    # 状态判断有坑: "discharging" 和 "not charging" 都包含子串 "charging",
    # 用 *charging* 通配会把拔电误判成仍在充电 —— 会话就永远不会结算,
    # 表现为"充完电没有生成记录"。必须先排除否定形式, 再判正向。
    case "$st" in
        *discharging*) is_chg=0 ;;
        *not*charging*) is_chg=0 ;;
        full|*full*) is_chg=0 ;;
        *charging*) is_chg=1 ;;
        *) is_chg=0 ;;
    esac
    lv=$(cat "$bat/capacity" 2>/dev/null | tr -cd '0-9')
    [ -z "$lv" ] && return 0
    t=$(date +%s 2>/dev/null)
    [ -z "$t" ] && t=0

    if [ "$is_chg" = "1" ]; then
        if [ ! -f "$CHG_STATE" ]; then
            # 会话开始: 立刻记第一条, 不等下一轮(否则短暂充电只有 1 个点)
            echo "$t" > "$CHG_STATE" 2>/dev/null
            echo "$lv" > "$CHG_FROM" 2>/dev/null
            echo 0 > "$CHG_N" 2>/dev/null
            # 功率统计必须一并清零, 否则会带着上次的累加值算平均
            rm -f "$CHG_SUMP" "$CHG_MAXP" "$CHG_NP" 2>/dev/null
        else
            sT=$(cat "$CHG_STATE" 2>/dev/null | tr -cd '0-9')
            # 异常长的会话强制结算重开, 防止时长虚高
            if [ -n "$sT" ] && [ "$sT" -gt 0 ] && [ $((t - sT)) -gt "$MAX_SESSION_SEC" ]; then
                settle_session
                echo "$t" > "$CHG_STATE" 2>/dev/null
                echo "$lv" > "$CHG_FROM" 2>/dev/null
                echo 0 > "$CHG_N" 2>/dev/null
                rm -f "$CHG_SUMP" "$CHG_MAXP" "$CHG_NP" 2>/dev/null
            fi
        fi
        n=$(cat "$CHG_N" 2>/dev/null | tr -cd '0-9')
        [ -z "$n" ] && n=0
        echo $((n + 1)) > "$CHG_N" 2>/dev/null
        echo "$lv" > "$CHG_LAST" 2>/dev/null
        echo "$t" > "$CHG_LASTT" 2>/dev/null
        # 采样同时记录功率: 电压(µV) × 电流(µA) → mW
        local v cur pw
        v=$(cat "$bat/voltage_now"   2>/dev/null | tr -cd '0-9')
        cur=$(cat "$bat/current_now" 2>/dev/null | tr -cd '0-9')
        pw=0
        if [ -n "$v" ] && [ -n "$cur" ]; then
            # 单位换算: voltage_now=µV, current_now=µA
            #   W  = (µV/1e6) × (µA/1e6)
            #   mW = W × 1000 = (v/1000) × (c/1e6)
            # 之前写成 (v/1000)*(c/1000), 得到的是 µW, 大了 1000 倍,
            # 表现为平均功率显示成上万瓦。
            pw=$(awk -v c="$cur" -v vv="$v" 'BEGIN{printf "%d", (vv/1000)*(c/1000000)}')
            [ -z "$pw" ] && pw=0
        fi
        # 电流为负(放电)时不计入功率统计, 避免拉低平均值
        if [ "$pw" -gt 0 ]; then
            local smp mxp npc
            smp=$(cat "$CHG_SUMP" 2>/dev/null | tr -cd '0-9'); [ -z "$smp" ] && smp=0
            mxp=$(cat "$CHG_MAXP" 2>/dev/null | tr -cd '0-9'); [ -z "$mxp" ] && mxp=0
            npc=$(cat "$CHG_NP" 2>/dev/null | tr -cd '0-9');   [ -z "$npc" ] && npc=0
            echo $((smp + pw)) > "$CHG_SUMP" 2>/dev/null
            [ "$pw" -gt "$mxp" ] && echo "$pw" > "$CHG_MAXP" 2>/dev/null
            echo $((npc + 1)) > "$CHG_NP" 2>/dev/null
        fi
        printf '{"t":%s,"l":%s,"p":%s}\n' "$t" "$lv" "$pw" >> "$CHARGE_LOG" 2>/dev/null || true
        # 日志截断计数与会话点数必须分开:
        # 若复用同一个变量并重置, 会破坏会话里的点数统计。
        SAMPLE_COUNT=$((SAMPLE_COUNT + 1))
        if [ "$SAMPLE_COUNT" -ge 50 ]; then
            SAMPLE_COUNT=0
            if [ -f "$CHARGE_LOG" ]; then
                tail -n 1500 "$CHARGE_LOG" > "$CHARGE_LOG.tmp" 2>/dev/null && \
                    mv "$CHARGE_LOG.tmp" "$CHARGE_LOG" 2>/dev/null || true
            fi
        fi
    else
        # 拔电(或从未充电): 若存在未结算会话, 立即结算
        [ -f "$CHG_STATE" ] && settle_session
    fi
    return 0
}

# 维持 PPS 认证解锁: 节点重启会被重置, 需重新写
apply_pd() {
    [ -f "$PD_FLAG" ] || return 0
    local n
    for n in /sys/class/qcom-battery/pd_verifed \
             /sys/class/qcom-battery/pd_verified \
             /sys/class/Charging_Adapter/pd_adapter/usbpd_verifed \
             /sys/class/Charging_Adapter/pd_adapter/usbpd_verified \
             /sys/class/power_supply/battery/pd_verifed; do
        [ -f "${SYS_ROOT}$n" ] && echo 1 > "${SYS_ROOT}$n" 2>/dev/null || true
    done
    return 0
}

# 维持降压: 同样会被重置
# 维持关机/开机电压: 节点重启后会被内核重置
apply_volt_thresh() {
    local v n raw
    if [ -f "$SDV_FLAG" ]; then
        v=$(cat "$SDV_FILE" 2>/dev/null | tr -cd '0-9')
        [ -n "$v" ] || return 0
        for n in /sys/class/power_supply/battery/voltage_min \
                 /sys/class/power_supply/bms/voltage_min \
                 /sys/class/power_supply/battery/shutdown_voltage \
                 /sys/class/power_supply/battery/vbat_shutdown \
                 /sys/class/qcom-battery/shutdown_voltage \
                 /sys/class/xm_power/fg_basic/shutdown_voltage; do
            [ -f "${SYS_ROOT}$n" ] || continue
            raw=$(cat "${SYS_ROOT}$n" 2>/dev/null | tr -cd '0-9')
            chmod 644 "${SYS_ROOT}$n" 2>/dev/null
            if [ -n "$raw" ] && [ ${#raw} -ge 6 ]; then
                echo $((v * 1000)) > "${SYS_ROOT}$n" 2>/dev/null || true
            else
                echo "$v" > "${SYS_ROOT}$n" 2>/dev/null || true
            fi
        done
    fi
    if [ -f "$BOV_FLAG" ]; then
        v=$(cat "$BOV_FILE" 2>/dev/null | tr -cd '0-9')
        [ -n "$v" ] || return 0
        for n in /sys/class/power_supply/battery/voltage_boot \
                 /sys/class/power_supply/bms/voltage_boot \
                 /sys/class/power_supply/battery/boot_voltage \
                 /sys/class/power_supply/battery/poweron_voltage \
                 /sys/class/qcom-battery/boot_voltage \
                 /sys/class/xm_power/fg_basic/boot_voltage; do
            [ -f "${SYS_ROOT}$n" ] || continue
            raw=$(cat "${SYS_ROOT}$n" 2>/dev/null | tr -cd '0-9')
            chmod 644 "${SYS_ROOT}$n" 2>/dev/null
            if [ -n "$raw" ] && [ ${#raw} -ge 6 ]; then
                echo $((v * 1000)) > "${SYS_ROOT}$n" 2>/dev/null || true
            else
                echo "$v" > "${SYS_ROOT}$n" 2>/dev/null || true
            fi
        done
    fi
    return 0
}

main_loop() {
    wait_until_login
    sleep "$BOOT_DELAY"
    # 开机立即应用一次容量/电压(节点重启后被重置, 需立刻恢复)
    apply_capacity
    apply_voltage
    apply_pd
    apply_volt_thresh
    [ -x "$MODDIR/action.sh" ] && sh "$MODDIR/action.sh" update >/dev/null 2>&1 || true

    tick=0
    was_fake=0
    while true; do
        # 每轮重新读取开关与伪装值 (用户可能已通过 action.sh 修改)
        has_fake=0; has_unlock=0; has_cloud=0; has_cap=0; has_volt=0
        [ -f "$FAKE_FLAG" ] && has_fake=1
        [ -f "$PERSIST_FLAG" ] && has_unlock=1
        [ -f "$CLOUD_FLAG" ] && has_cloud=1
        [ -f "$CAP_FLAG" ] && has_cap=1
        [ -f "$VOLT_FLAG" ] && has_volt=1
        # 云控是否需要处理:
        #   - 有 CLOUD_FLAG 的老用户(升级前装的) → 继续维持禁用
        #   - 设置了策略文件 → 按模式, off 则不处理
        #   - 两者都无 → 不处理, 不阻止守护退出
        has_cloud=0
        [ -f "$CLOUD_FLAG" ] && has_cloud=1
        if [ -f "$CLOUD_MODE_FILE" ]; then
            if [ "$(cloud_mode)" = "off" ]; then has_cloud=0; else has_cloud=1; fi
        fi
        # 充电记录是否启用
        has_chargelog=0
        [ -f "$CHARGE_LOG_FLAG" ] && has_chargelog=1

        # 充电采样
        [ "$has_chargelog" = "1" ] && charge_sample

        # 所有开关都关 → 无事可做, 退出不空转
        # (pd 也要计入, 否则只开这一项时守护会退出, 节点重置后没人恢复)
        has_pd=0
        [ -f "$PD_FLAG" ] && has_pd=1
        if [ "$has_fake" = "0" ] && [ "$has_unlock" = "0" ] && [ "$has_cloud" = "0" ] \
           && [ "$has_cap" = "0" ] && [ "$has_volt" = "0" ] && [ "$has_chargelog" = "0" ] \
           && [ "$has_pd" = "0" ] && [ ! -f "$SDV_FLAG" ] && [ ! -f "$BOV_FLAG" ]; then
            [ "$was_fake" = "1" ] && restore_real_cycle
            break
        fi

        if [ "$has_fake" = "1" ]; then
            val=$(cat "$FAKE_FILE" 2>/dev/null | tr -cd '0-9')
            [ -z "$val" ] && val=20
            write_cycle_if_needed "$val"
            was_fake=1
        else
            # 伪装刚被关闭 → 还原真实值, 避免节点停留在伪装值
            if [ "$was_fake" = "1" ]; then
                restore_real_cycle
                was_fake=0
            fi
        fi

        # 容量/电压节点会被内核重置, 每轮检测并维持
        [ "$has_cap" = "1" ] && apply_capacity
        [ "$has_volt" = "1" ] && apply_voltage

        # 云控禁用 / 解容重建: 降频执行
        tick=$((tick + 1))
        if [ "$tick" -ge "$HEAVY_TICK" ]; then
            apply_pd
            apply_volt_thresh
            [ "$has_cloud" = "1" ] && disable_cloud
            [ "$has_unlock" = "1" ] && rebuild_unlock
            tick=0
        fi

        # 充电中提高采样频率: 60 秒一个点太稀, 曲线看不出阶梯变化
        # 非充电时恢复常规间隔, 避免无谓开销
        if [ -f "$CHG_STATE" ] && [ "$has_chargelog" = "1" ]; then
            sleep "${CHARGE_INTERVAL:-20}"
        else
            sleep "$INTERVAL"
        fi
    done
    rm -f "$LOCK" 2>/dev/null
}

# 主循环放后台, 主脚本立即退出, 不阻塞开机
main_loop >/dev/null 2>&1 &
echo $! > "$LOCK" 2>/dev/null

exit 0
